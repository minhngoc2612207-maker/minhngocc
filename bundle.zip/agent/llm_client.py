"""
LLM Client module for Google Gemini API integration.
Supports REST API v1beta directly with retries, timeout management, JSON mode,
and graceful fallback when API key is not configured or network is unreachable.
"""

import os
import json
import time
import re
import requests
from typing import Dict, Any, Optional

import tempfile

def _resolve_config_file() -> str:
    base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    default_conf = os.path.join(base, "config.json")
    try:
        if os.path.exists(default_conf):
            return default_conf
        test_file = os.path.join(base, ".conf_test")
        with open(test_file, "w") as f:
            f.write("1")
        os.remove(test_file)
        return default_conf
    except Exception:
        return os.path.join(tempfile.gettempdir(), "config.json")

CONFIG_FILE = _resolve_config_file()


def load_config() -> Dict[str, Any]:
    """Loads configuration from config.json with fallback defaults."""
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {
        "gemini_api_key": os.environ.get("GEMINI_API_KEY", ""),
        "gemini_model": "gemini-2.5-flash",
        "temperature": 0.2,
        "server_port": 5000
    }


def save_config(config_data: Dict[str, Any]) -> bool:
    """Saves updated configuration to config.json."""
    try:
        current = load_config()
        current.update(config_data)
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(current, f, indent=2, ensure_ascii=False)
        return True
    except Exception as e:
        print(f"Error saving config: {e}")
        return False


def get_api_key() -> str:
    """Retrieves the active Gemini API key from config or environment."""
    config = load_config()
    key = config.get("gemini_api_key", "").strip()
    if not key:
        key = os.environ.get("GEMINI_API_KEY", "").strip()
    return key


def get_model_name() -> str:
    """Returns the configured model name."""
    config = load_config()
    return config.get("gemini_model", "gemini-2.5-flash").strip()


def call_gemini(
    prompt: str,
    system_instruction: Optional[str] = None,
    json_mode: bool = False,
    max_tokens: int = 4096,
    temperature: float = 0.2
) -> Dict[str, Any]:
    """
    Calls Google Gemini REST API.
    Returns:
        {
            "success": True/False,
            "text": "...",
            "data": {...} (if json_mode and parsed),
            "model": "...",
            "source": "GEMINI_API" or "FALLBACK",
            "error": "..." (if any)
        }
    """
    api_key = get_api_key()
    model = get_model_name()

    if not api_key:
        return {
            "success": False,
            "text": "",
            "data": None,
            "model": model,
            "source": "FALLBACK",
            "error": "Chưa cấu hình GEMINI_API_KEY. Vui lòng nhập API Key trong phần Cấu hình."
        }

    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}"

    payload: Dict[str, Any] = {
        "contents": [
            {
                "parts": [
                    {"text": prompt}
                ]
            }
        ],
        "generationConfig": {
            "temperature": temperature,
            "maxOutputTokens": max_tokens
        }
    }

    if system_instruction:
        payload["systemInstruction"] = {
            "parts": [{"text": system_instruction}]
        }

    if json_mode:
        payload["generationConfig"]["responseMimeType"] = "application/json"

    headers = {
        "Content-Type": "application/json"
    }

    max_retries = 2
    last_error = ""

    for attempt in range(max_retries + 1):
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=40)
            if response.status_code == 200:
                res_json = response.json()
                candidates = res_json.get("candidates", [])
                if candidates:
                    parts = candidates[0].get("content", {}).get("parts", [])
                    raw_text = "".join([p.get("text", "") for p in parts]).strip()

                    parsed_data = None
                    if json_mode or raw_text.startswith("{") or "```json" in raw_text:
                        parsed_data = parse_json_from_text(raw_text)

                    return {
                        "success": True,
                        "text": raw_text,
                        "data": parsed_data,
                        "model": model,
                        "source": "GEMINI_API",
                        "error": None
                    }
                else:
                    return {
                        "success": False,
                        "text": "",
                        "data": None,
                        "model": model,
                        "source": "GEMINI_API",
                        "error": "Không có ứng viên phản hồi từ Gemini API (safety block hoặc rỗng)."
                    }
            else:
                last_error = f"Gemini API HTTP {response.status_code}: {response.text[:200]}"
                if response.status_code in [429, 500, 503] and attempt < max_retries:
                    time.sleep(2 * (attempt + 1))
                    continue
                break
        except requests.exceptions.Timeout:
            last_error = "Gemini API Timeout (quá thời gian chờ 40s)."
            if attempt < max_retries:
                time.sleep(2)
                continue
        except Exception as e:
            last_error = f"Lỗi kết nối Gemini API: {str(e)}"
            break

    return {
        "success": False,
        "text": "",
        "data": None,
        "model": model,
        "source": "FALLBACK",
        "error": last_error
    }


def parse_json_from_text(text: str) -> Optional[Dict[str, Any]]:
    """Helper to extract and parse JSON object from raw response text."""
    if not text:
        return None
    # Strip markdown code blocks
    cleaned = text.strip()
    if cleaned.startswith("```json"):
        cleaned = cleaned[7:]
    elif cleaned.startswith("```"):
        cleaned = cleaned[3:]
    if cleaned.endswith("```"):
        cleaned = cleaned[:-3]
    cleaned = cleaned.strip()

    try:
        return json.loads(cleaned)
    except Exception:
        # Try regex search for first outermost { ... }
        match = re.search(r"(\{.*\})", cleaned, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(1))
            except Exception:
                pass
    return None


def test_connection(api_key: Optional[str] = None, model: Optional[str] = None) -> Dict[str, Any]:
    """Tests live connection to Gemini API with a short ping."""
    key = api_key.strip() if api_key else get_api_key()
    mod = model.strip() if model else get_model_name()

    if not key:
        return {
            "success": False,
            "message": "Vui lòng nhập API Key trước khi kiểm tra kết nối.",
            "latency_ms": 0
        }

    url = f"https://generativelanguage.googleapis.com/v1beta/models/{mod}:generateContent?key={key}"
    payload = {
        "contents": [{"parts": [{"text": "Chào bạn, hãy phản hồi chữ 'OK' để kiểm tra kết nối."}]}],
        "generationConfig": {"maxOutputTokens": 20, "temperature": 0.0}
    }

    start = time.time()
    try:
        resp = requests.post(url, json=payload, headers={"Content-Type": "application/json"}, timeout=12)
        latency = int((time.time() - start) * 1000)
        if resp.status_code == 200:
            return {
                "success": True,
                "message": f"Kết nối Gemini API thành công! Mô hình: {mod} ({latency}ms)",
                "latency_ms": latency
            }
        else:
            return {
                "success": False,
                "message": f"Kết nối thất bại (HTTP {resp.status_code}): {resp.text[:250]}",
                "latency_ms": latency
            }
    except Exception as e:
        latency = int((time.time() - start) * 1000)
        return {
            "success": False,
            "message": f"Không thể kết nối đến Gemini: {str(e)}",
            "latency_ms": latency
        }

