"""
Verification Router module:
Generates and manages cross-functional verification checklists/tickets
for Sales, Operations/Service, and Finance departments.
"""

from typing import Dict, Any, List
from datetime import datetime


def generate_verification_tickets(intake_data: Dict[str, Any], compliance_res: Dict[str, Any]) -> Dict[str, Any]:
    """
    Automatically produces 3 department-specific verification checklists
    customized based on applicant claims and compliance findings.
    """
    legal = intake_data.get("legal_entity", {})
    location = intake_data.get("location_logistics", {})
    commercial = intake_data.get("commercial_commitment", {})
    technical = intake_data.get("technical_service", {})
    financial = intake_data.get("financial_credit", {})

    company_name = legal.get("company_name", "Đối tác mới")
    committed_rev = commercial.get("committed_monthly_revenue", 0)
    declared_techs = technical.get("technician_count", 0)
    declared_area = technical.get("workshop_area_m2", 0)
    req_credit = financial.get("requested_credit_limit", 0)
    req_debt_days = financial.get("requested_debt_days", 0)

    now_str = datetime.now().strftime("%Y-%m-%d %H:%M")

    # 1. Sales Dept Checklist
    sales_ticket = {
        "dept_code": "SALES",
        "dept_name": "Phòng Kinh Doanh",
        "status": "PENDING",  # PENDING, IN_PROGRESS, COMPLETED
        "created_at": now_str,
        "assignee": "Chuyên viên PTKD Khu vực",
        "focus_areas": [
            f"Thẩm định lưu lượng khách thực tế tại điểm bán: {location.get('address', 'Chưa có địa chỉ')}",
            f"Đánh giá tính khả thi mức cam kết doanh số {committed_rev:,} VNĐ/tháng (so sánh với sức mua thị trường xung quanh)",
            f"Khảo sát bề rộng mặt tiền (khai báo {location.get('store_front_width_m', 0)}m) và vị trí trưng bày sản phẩm Đại Thành",
            "Kiểm tra tệp khách hàng bán lẻ / đại lý cấp 2 hiện hữu của đối tác"
        ],
        "findings": {
            "traffic_rating": "Trungh bình",  # Cao, Trung bình, Thấp
            "verified_monthly_revenue": committed_rev,  # có thể điều chỉnh lại
            "market_competition_level": "Vừa phải",  # Thấp, Vừa phải, Khốc liệt
            "sales_network_confirmed": True,
            "assessor_notes": f"Đã tiếp nhận hồ sơ {company_name}. Điểm bán có vị trí thuận lợi, cam kết doanh số cần được kiểm chứng qua tháng chạy thử đầu tiên.",
            "is_approved": True
        }
    }

    # 2. Operations & Service Dept Checklist
    service_ticket = {
        "dept_code": "OPERATIONS",
        "dept_name": "Phòng Vận Hành & Dịch Vụ Kỹ Thuật",
        "status": "PENDING",
        "created_at": now_str,
        "assignee": "Trưởng trạm Kỹ thuật Dịch vụ",
        "focus_areas": [
            f"Kiểm tra nhân sự thợ kỹ thuật cơ hữu (Khai báo: {declared_techs} thợ. Yêu cầu tối thiểu của hãng: 2 thợ)",
            f"Khảo sát diện tích trạm/xưởng bảo hành sửa chữa (Khai báo: {declared_area}m². Tiêu chuẩn: >= 15m²)",
            f"Đánh giá năng lực đáp ứng cam kết SLA 48h đối với bảo hành bếp từ và máy lọc nước",
            "Kiểm tra trang thiết bị đo đạc, đồ nghề chuyên dụng và giá kệ tồn trữ linh kiện"
        ],
        "findings": {
            "verified_technicians": declared_techs,
            "verified_workshop_area": declared_area,
            "sla_capable": technical.get("sla_commit_hours", 48) <= 48 and declared_techs >= 1,
            "has_spare_parts_shelf": declared_area >= 15,
            "assessor_notes": (
                "Cảnh báo: Khai báo 0 thợ kỹ thuật hoặc không có xưởng dịch vụ! Nguy cơ rất cao đối tác chỉ bán kiếm lời và đùn đẩy bảo hành cho hãng."
                if declared_techs == 0 or declared_area < 10 else
                f"Đã xác minh cơ sở vật chất: Có {declared_techs} thợ và xưởng {declared_area}m², đáp ứng tiêu chuẩn trạm dịch vụ ủy quyền."
            ),
            "is_approved": declared_techs >= 2 and declared_area >= 15
        }
    }

    # 3. Finance Dept Checklist
    finance_ticket = {
        "dept_code": "FINANCE",
        "dept_name": "Phòng Tài Chính & Kế Toán Quản Trị",
        "status": "PENDING",
        "created_at": now_str,
        "assignee": "Kế toán trưởng & Chuyên viên Thẩm định Tín dụng",
        "focus_areas": [
            f"Tra cứu lịch sử tín dụng CIC của pháp nhân {company_name} (MST: {legal.get('tax_id')})",
            f"Thẩm định đề xuất hạn mức tín chấp {req_credit:,} VNĐ và thời hạn nợ {req_debt_days} ngày",
            "Kiểm tra tính pháp lý và bảo lãnh thanh toán không hủy ngang từ Ngân hàng (nếu hạn mức > 500 triệu)",
            "Đánh giá báo cáo tài chính 2 năm gần nhất và dòng tiền hoạt động"
        ],
        "findings": {
            "cic_group": "Nhóm 1 - Nợ đủ tiêu chuẩn",  # Nhóm 1, Nhóm 2, Nhóm 3-5
            "verified_bank_guarantee": financial.get("has_bank_guarantee", False),
            "cashflow_health": "Khá",  # Mạnh, Khá, Yếu, Rủi ro
            "assessor_notes": (
                f"Hồ sơ đề xuất nợ {req_debt_days} ngày. Nếu nợ > 30 ngày cần yêu cầu rút ngắn về 30 ngày theo quy chế tài chính."
                if req_debt_days > 30 else
                f"Hạn mức {req_credit:,} VNĐ nằm trong giới hạn kiểm soát tài chính. CIC Nhóm 1 sạch."
            ),
            "is_approved": req_debt_days <= 45 and (req_credit <= 500000000 or financial.get("has_bank_guarantee", False))
        }
    }

    return {
        "summary": "Đã khởi tạo đồng thời 3 phiếu khảo sát liên phòng ban (Kinh doanh, Vận hành, Tài chính).",
        "all_approved": False,
        "tickets": {
            "sales": sales_ticket,
            "operations": service_ticket,
            "finance": finance_ticket
        }
    }


def update_verification_ticket(
    current_tickets: Dict[str, Any],
    dept_code: str,
    update_data: Dict[str, Any]
) -> Dict[str, Any]:
    """Updates findings and approval status for a specific department ticket."""
    tickets = current_tickets.get("tickets", {})
    key_map = {
        "SALES": "sales",
        "OPERATIONS": "operations",
        "FINANCE": "finance"
    }
    dept_key = key_map.get(dept_code.upper())
    if dept_key and dept_key in tickets:
        ticket = tickets[dept_key]
        findings = ticket.get("findings", {})
        findings.update(update_data)
        ticket["findings"] = findings
        ticket["status"] = "COMPLETED"
        ticket["updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M")

    # Check overall approval
    all_ok = all(
        t.get("findings", {}).get("is_approved", False)
        for t in tickets.values()
    )
    current_tickets["all_approved"] = all_ok
    return current_tickets

