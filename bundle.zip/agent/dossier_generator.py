"""
Dossier Generator module:
1. Generates Executive Strategic Assessment via Gemini LLM or advanced heuristic reasoning.
2. Formulates Corporate Response Email / Letter tailored to decision.
3. Compiles Conditions Precedent (Điều kiện tiên quyết) prior to contract signing.
4. Generates branded, styled Excel (.xlsx) reports using openpyxl.
"""

import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from agent.llm_client import call_gemini


def generate_strategic_assessment(
    intake_data: Dict[str, Any],
    compliance_res: Dict[str, Any],
    score_res: Dict[str, Any],
    verification_tickets: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Produces sharp executive strategic assessment of the applicant.
    Uses Gemini LLM if available; otherwise uses deterministic expert heuristic.
    """
    legal = intake_data.get("legal_entity", {})
    location = intake_data.get("location_logistics", {})
    commercial = intake_data.get("commercial_commitment", {})
    technical = intake_data.get("technical_service", {})
    financial = intake_data.get("financial_credit", {})

    company_name = legal.get("company_name", "Đối tác")
    tax_id = legal.get("tax_id", "")
    committed_rev = commercial.get("committed_monthly_revenue", 0)
    req_debt_days = financial.get("requested_debt_days", 0)
    req_credit = financial.get("requested_credit_limit", 0)
    tech_count = technical.get("technician_count", 0)
    has_bg = financial.get("has_bank_guarantee", False)

    is_phantom = score_res.get("is_phantom_commitment", False)
    final_score = score_res.get("final_score", 0)
    tier = score_res.get("tier", "Tier D")
    violations = compliance_res.get("violations", [])
    nearest = compliance_res.get("nearest_partner")

    system_prompt = """
Bạn là Cố vấn Chiến lược Cấp cao kiêm Giám đốc Phát triển Kênh Phân phối của Công ty Cổ phần Thiết bị Gia dụng Đại Thành.
Hãy đưa ra một Báo cáo Thẩm định Chiến lược (Executive Strategic Assessment) thật sắc bén, thực tế và sâu sát về mặt kinh doanh cho Trưởng phòng PTKD.

Yêu cầu trả về đúng định dạng JSON:
{
  "executive_summary": "Tóm lược đánh giá bản chất hồ sơ đối tác trong 2-3 câu ngắn gọn nhưng đắt giá",
  "hidden_motives_analysis": "Phân tích động cơ ngầm của đối tác (ví dụ: đòi nợ dài để quay vòng vốn, cam kết ảo để hưởng chiết khấu, ôm hàng phá giá, đùn đẩy bảo hành)",
  "brand_and_market_risks": "Các nguy cơ trực tiếp đối với uy tín thương hiệu Đại Thành và xung đột mạng lưới",
  "recommended_counter_strategy": "Kịch bản và điều kiện đàm phán nắm đằng chuôi cho Đại Thành",
  "preliminary_decision": "TIẾP TỤC" hoặc "BỔ SUNG ĐIỀU KIỆN" hoặc "CHƯA TIẾP TỤC"
}
"""

    prompt = f"""
Hồ sơ đối tác: {company_name} (MST: {tax_id}, Khu vực: {legal.get('region')})
Địa chỉ: {location.get('address')}
Doanh số cam kết: {committed_rev:,} VNĐ/tháng
Đề xuất công nợ: {req_debt_days} ngày, hạn mức {req_credit:,} VNĐ (Bảo lãnh NH: {has_bg})
Năng lực kỹ thuật: {tech_count} thợ KTV, xưởng {technical.get('workshop_area_m2')} m², SLA: {technical.get('sla_commit_hours')}h
Điểm thẩm định: {final_score}/100 ({tier})
Cảnh báo Cam kết ảo: {is_phantom}
Vi phạm tuân thủ: {json.dumps(violations, ensure_ascii=False)}
Đại lý gần nhất: {json.dumps(nearest, ensure_ascii=False) if nearest else "Không có"}
"""

    llm_res = call_gemini(prompt=prompt, system_instruction=system_prompt, json_mode=True)
    if llm_res.get("success") and llm_res.get("data"):
        data = llm_res["data"]
        data["source"] = "GEMINI_AI"
        return data

    # Intelligent Fallback Heuristic
    if is_phantom:
        summary = f"CẢNH BÁO ĐỎ: {company_name} có dấu hiệu điển hình của 'Bẫy Cam Kết Ảo'. Cam kết doanh số lớn ({committed_rev:,} VNĐ) nhằm đòi chiết khấu Cấp 1 và công nợ {req_debt_days} ngày, nhưng đội ngũ kỹ thuật hoàn toàn trống rỗng ({tech_count} thợ)."
        motives = "Đối tác muốn tận dụng chính sách tân đại lý để nhập lô hàng lớn với chiết khấu cao nhất, gối đầu công nợ dài ngày để lấy vốn lưu động kinh doanh mặt hàng khác. Đùn đẩy 100% trách nhiệm bảo hành, bảo trì thiết bị (bếp từ, máy lọc nước) về cho trung tâm dịch vụ khách hàng của hãng."
        risks = "Gia tăng áp lực khiếu nại dịch vụ sau bán hàng từ người tiêu dùng do không có thợ tại chỗ. Nguy cơ bán tháo hạ giá gây hỗn loạn hệ thống phân phối khi gặp áp lực dòng tiền."
        strategy = "Tuyệt đối không cấp nợ tín chấp. Nếu hợp tác, bắt buộc ký quỹ 100% tiền mặt hoặc Thư bảo lãnh ngân hàng. Yêu cầu ký cam kết tuyển dụng đủ 2 KTV chuyên trách và chiết khấu bị giảm 3% để chuyển quỹ hỗ trợ trạm bảo hành của hãng."
        decision = "CHƯA TIẾP TỤC"
    elif violations:
        summary = f"Hồ sơ {company_name} có tiềm lực nhưng vướng xung đột địa bàn hoặc vi phạm trần công nợ của Đại Thành."
        motives = "Đối tác muốn mở rộng thị phần tại khu vực trung tâm nhưng chưa nắm rõ hoặc cố tình lấn sân vào địa bàn độc quyền của đại lý hiện hữu của hãng."
        risks = "Gây bức xúc và nguy cơ tẩy chay sản phẩm từ Đại lý Cấp 1 kỳ cựu do vi phạm bán kính bảo hộ. Rủi ro công nợ nếu áp dụng thời hạn nợ dài hơn chuẩn 30 ngày."
        strategy = "Đàm phán phân vùng hẹp hơn, hoặc chỉ cấp quyền phân phối độc quyền một dải sản phẩm mới (ví dụ dòng Quạt điều hòa cao cấp) mà đại lý lân cận chưa kinh doanh mạnh. Rút hạn mức nợ về đúng chuẩn <= 30 ngày."
        decision = "BỔ SUNG ĐIỀU KIỆN"
    elif final_score >= 80:
        summary = f"{company_name} là đối tác phân phối chất lượng cao (Tier A - {final_score}đ). Cơ sở hạ tầng, tài chính và năng lực kỹ thuật đều vượt chuẩn."
        motives = "Mong muốn thiết lập quan hệ đối tác chiến lược dài hạn, trở thành tổng kho hoặc trung tâm phân phối chủ lực của Đại Thành tại khu vực."
        risks = "Rủi ro thấp. Cần hỗ trợ tốt về nhận diện thương hiệu biển bảng và đào tạo kỹ thuật chuyên sâu để đối tác vận hành trơn tru."
        strategy = "Nhanh chóng tiến hành ký hợp đồng nguyên tắc. Áp dụng chính sách thưởng doanh số năm và bàn giao chứng nhận Trạm Bảo Hành Ủy Quyền Cấp 1."
        decision = "TIẾP TỤC"
    else:
        summary = f"Hồ sơ {company_name} đạt mức điểm trung bình ({final_score}đ - {tier}). Năng lực ở mức vừa phải, cần thận trọng trong phân cấp đối tác."
        motives = "Thử nghiệm thị trường thiết bị gia dụng Đại Thành với quy mô nhỏ, khả năng mở rộng kênh chưa rõ nét."
        risks = "Tốc độ luân chuyển hàng chậm, năng lực xử lý kỹ thuật chưa độc lập hoàn toàn."
        strategy = "Chỉ mở mã đại lý cấp 2 bán lẻ, áp dụng hình thức thanh toán trước khi nhận hàng (tiền mặt / chuyển khoản), không áp dụng hạn mức công nợ gối đầu."
        decision = "BỔ SUNG ĐIỀU KIỆN"

    return {
        "executive_summary": summary,
        "hidden_motives_analysis": motives,
        "brand_and_market_risks": risks,
        "recommended_counter_strategy": strategy,
        "preliminary_decision": decision,
        "source": "EXPERT_HEURISTIC"
    }


def generate_conditions_precedent(
    intake_data: Dict[str, Any],
    decision: str,
    score_res: Dict[str, Any],
    compliance_res: Dict[str, Any]
) -> List[Dict[str, Any]]:
    """Generates mandatory Conditions Precedent (Điều kiện tiên quyết) prior to signing contract."""
    conditions = []
    financial = intake_data.get("financial_credit", {})
    technical = intake_data.get("technical_service", {})
    location = intake_data.get("location_logistics", {})

    req_credit = financial.get("requested_credit_limit", 0)
    req_debt_days = financial.get("requested_debt_days", 0)
    has_bg = financial.get("has_bank_guarantee", False)
    tech_count = technical.get("technician_count", 0)

    # Condition 1: Financial Security
    if req_credit > 500000000 or not has_bg:
        conditions.append({
            "category": "Tài chính & Bảo lãnh",
            "condition": "Nộp Thư bảo lãnh thanh toán vô điều kiện và không hủy ngang do Ngân hàng thương mại phát hành cho hạn mức tín dụng vượt trần tín chấp.",
            "mandatory": True,
            "deadline": "Trước ngày ký hợp đồng 03 ngày làm việc"
        })

    # Condition 2: Debt Term adjustment
    if req_debt_days > 30:
        conditions.append({
            "category": "Chính sách Công nợ",
            "condition": f"Ký phụ lục chấp thuận điều chỉnh thời hạn nợ gối đầu từ {req_debt_days} ngày về chuẩn tối đa 30 ngày theo Quy chế Tài chính Tập đoàn Đại Thành.",
            "mandatory": True,
            "deadline": "Tại thời điểm ký kết Hợp đồng Phân phối"
        })

    # Condition 3: Technical personnel & warranty
    if tech_count < 2:
        conditions.append({
            "category": "Nhân sự & Dịch vụ Kỹ thuật",
            "condition": "Hoàn tất tuyển dụng tối thiểu 02 Kỹ thuật viên cơ hữu có chứng chỉ điện/điện tử và cử tham gia khóa đào tạo chứng chỉ kỹ thuật tại Nhà máy Đại Thành.",
            "mandatory": True,
            "deadline": "Trong vòng 15 ngày kể từ ngày kích hoạt mã đại lý"
        })

    # Condition 4: Geofencing & Channel protection
    if compliance_res.get("radius_violation_partner") or compliance_res.get("exclusive_district_conflict"):
        conditions.append({
            "category": "Bảo hộ Địa bàn & Kênh phân phối",
            "condition": "Ký cam kết không bán lấn vùng bảo hộ độc quyền của Đại lý lân cận và chỉ phân phối dải sản phẩm được phân bổ đặc thù.",
            "mandatory": True,
            "deadline": "Kèm theo Hợp đồng nguyên tắc"
        })

    # Condition 5: Storefront signage & showroom
    conditions.append({
        "category": "Nhận diện Thương hiệu",
        "condition": "Thi công lắp đặt biển bảng nhận diện Đại Thành chuẩn quy cách thương hiệu và bố trí diện tích trưng bày tối thiểu 20m² tại mặt tiền.",
        "mandatory": False,
        "deadline": "Trước ngày khai trương điểm bán"
    })

    return conditions


def generate_draft_response_letter(
    intake_data: Dict[str, Any],
    decision: str,
    negotiation_notes: str,
    score_res: Dict[str, Any],
    compliance_res: Dict[str, Any],
    conditions_list: List[Dict[str, Any]]
) -> Dict[str, Any]:
    """
    Drafts official corporate response letter/email to the applicant.
    Tailors tone and content strictly to the Head of BD's final decision.
    """
    legal = intake_data.get("legal_entity", {})
    company_name = legal.get("company_name", "Quý Đối Tác")
    legal_rep = legal.get("legal_rep", "Giám đốc")
    tax_id = legal.get("tax_id", "")
    final_score = score_res.get("final_score", 0)
    tier = score_res.get("tier", "Tier D")

    system_prompt = """
Bạn là Trưởng phòng Phát triển Kênh Phân phối của Công ty Cổ phần Thiết bị Gia dụng Đại Thành.
Hãy soạn thảo một bức Thư / Email phản hồi chính thức gửi Người đại diện pháp luật của đối tác đăng ký phân phối.
Văn phong: Trang trọng, lịch sự, chuẩn mực doanh nghiệp lớn, rõ ràng và kiên định với chính sách chất lượng & tài chính của Đại Thành.

Trả về đối tượng JSON:
{
  "subject": "Tiêu đề email trang trọng",
  "recipient_name": "Tên người nhận",
  "salutation": "Lời chào",
  "opening_paragraph": "Đoạn mở đầu xác nhận tiếp nhận và cảm ơn sự quan tâm",
  "assessment_summary": "Tóm lược kết quả đánh giá hồ sơ và định vị đối tác",
  "decision_statement": "Tuyên bố quyết định chính thức (Tiếp tục mời ký kết / Bổ sung điều kiện đàm phán / Tạm hoãn hợp tác)",
  "terms_and_conditions": "Liệt kê rõ các điều kiện bắt buộc hoặc lý do cụ thể",
  "closing_action": "Các bước tiếp theo và thông tin đầu mối liên hệ",
  "full_letter_content": "Toàn văn bức thư được định dạng hoàn chỉnh, sẵn sàng gửi đi"
}
"""

    prompt = f"""
Thông tin đối tác: {company_name} (Người đại diện: {legal_rep}, MST: {tax_id})
Quyết định của Trưởng phòng PTKD: {decision}
Ghi chú đàm phán của Trưởng phòng: {negotiation_notes}
Điểm đánh giá: {final_score}/100 ({tier})
Các điều kiện tiên quyết: {json.dumps([c['condition'] for c in conditions_list], ensure_ascii=False)}
"""

    llm_res = call_gemini(prompt=prompt, system_instruction=system_prompt, json_mode=True)
    if llm_res.get("success") and llm_res.get("data"):
        return llm_res["data"]

    # High-quality Corporate Heuristic Fallback
    now_date = datetime.now().strftime("ngày %d tháng %m năm %Y")
    if decision == "TIẾP TỤC":
        subject = f"[ĐẠI THÀNH GROUP] THÔNG BÁO CHẤP THUẬN & MỜI KÝ KẾT HỢP ĐỒNG PHÂN PHỐI - {company_name.upper()}"
        decision_statement = "Hội đồng Thẩm định Kênh Phân phối Tập đoàn Đại Thành trân trọng thông báo: Hồ sơ đăng ký của Quý Công ty đã đáp ứng xuất sắc các tiêu chuẩn đánh giá năng lực thương mại, dịch vụ kỹ thuật và an toàn địa bàn."
        terms = "\n".join([f"- {c['category']}: {c['condition']} (Thời hạn: {c['deadline']})" for c in conditions_list])
        full_text = f"""CÔNG TY CỔ PHẦN THIẾT BỊ GIA DỤNG ĐẠI THÀNH
Hà Nội, {now_date}

THƯ THÔNG BÁO V/V CHẤP THUẬN NGUYÊN TẮC HỢP TÁC PHÂN PHỐI

Kính gửi: Ban Lãnh đạo {company_name}
Đồng kính gửi: Ông/Bà {legal_rep} - Người đại diện theo pháp luật

Lời đầu tiên, Ban Giám đốc Công ty Cổ phần Thiết bị Gia dụng Đại Thành xin gửi tới Quý Công ty lời chào trân trọng và lời chúc phát triển thịnh vượng!

Chúng tôi xin chân thành cảm ơn Quý Công ty đã quan tâm và nộp hồ sơ gia nhập Mạng lưới Đối tác Phân phối Thiết bị Gia dụng Đại Thành. Qua quá trình thẩm định liên phòng ban (Kinh doanh, Dịch vụ Kỹ thuật, Tài chính) và khảo sát thực địa, Ban Lãnh đạo Đại Thành đánh giá rất cao quy mô, tiềm lực tài chính và uy tín của Quý Công ty ({final_score}/100 điểm - Xếp hạng {tier}).

Bằng văn bản này, Công ty Cổ phần Thiết bị Gia dụng Đại Thành trân trọng thông báo CHẤP THUẬN NGUYÊN TẮC việc thiết lập quan hệ Hợp tác Phân phối chính thức đối với {company_name}.

Để tiến tới việc ký kết Hợp đồng Phân phối và kích hoạt Mã Đối tác trên Hệ thống Quản trị Kênh (DMS), kính đề nghị Quý Công ty phối hợp hoàn tất các Điều kiện Tiên quyết sau:
{terms}

Đầu mối phụ trách thủ tục ký kết:
Phòng Phát triển Kênh Phân phối - Công ty CP Thiết bị Gia dụng Đại Thành
Hotline Kênh: 1900 6886 | Email: ptkd@daithanh-group.vn

Rất mong sớm được đón tiếp Quý Công ty tại Lễ ký kết Hợp đồng hợp tác chiến lược!

Trân trọng,
TRƯỞNG PHÒNG PHÁT TRIỂN KÊNH PHÂN PHỐI
(Đã ký & Đóng dấu)"""

    elif decision == "BỔ SUNG ĐIỀU KIỆN":
        subject = f"[ĐẠI THÀNH GROUP] PHẢN HỒI HỒ SƠ ĐỐI TÁC & ĐỀ NGHỊ ĐÀM PHÁN ĐIỀU KHOẢN HỢP TÁC - {company_name.upper()}"
        decision_statement = "Hội đồng Thẩm định ghi nhận thiện chí và tiềm năng của Quý Công ty, tuy nhiên để đảm bảo an toàn vận hành và sự hài hòa của hệ sinh thái đại lý hiện hữu, Đại Thành đề xuất hai bên cùng thảo luận điều chỉnh một số điều kiện then chốt."
        terms = "\n".join([f"- {c['category']}: {c['condition']}" for c in conditions_list])
        if negotiation_notes:
            terms += f"\n- Phương án xử lý cụ thể từ Trưởng phòng PTKD: {negotiation_notes}"

        full_text = f"""CÔNG TY CỔ PHẦN THIẾT BỊ GIA DỤNG ĐẠI THÀNH
Hà Nội, {now_date}

THƯ PHẢN HỒI HỒ SƠ & ĐỀ NGHỊ ĐÀM PHÁN ĐIỀU KIỆN HỢP TÁC

Kính gửi: Ban Giám đốc {company_name}
Kính gửi: Ông/Bà {legal_rep} - Người đại diện theo pháp luật

Công ty Cổ phần Thiết bị Gia dụng Đại Thành xin gửi lời cảm ơn chân thành tới Quý Công ty đã gửi hồ sơ đăng ký tham gia mạng lưới phân phối của chúng tôi.

Sau khi Hội đồng Thẩm định hoàn thành việc rà soát hồ sơ và kiểm tra đối chiếu địa bàn (Tổng điểm thẩm định: {final_score}/100 điểm - Xếp hạng {tier}), chúng tôi đánh giá cao năng lực thương mại của Quý đối tác. Tuy nhiên, một số chỉ tiêu về chính sách công nợ, bảo lãnh hoặc vùng bảo hộ kỹ thuật cần được chuẩn hóa trước khi có thể ban hành hợp đồng:

CÁC NỘI DUNG ĐỀ NGHỊ THỐNG NHẤT & ĐIỀU CHỈNH:
{terms}

Chúng tôi trân trọng kính mời Đại diện có thẩm quyền của Quý Công ty tham dự buổi làm việc trực tiếp (hoặc trực tuyến) với Ban Phát triển Kênh của Đại Thành trong tuần tới để thống nhất phương án hợp tác tối ưu nhất cho cả hai bên.

Đầu mối liên hệ xếp lịch:
Bộ phận Quản lý Kênh Phân phối Đại Thành - ĐT: 024 3888 9999 (Máy lẻ 102)

Trân trọng hợp tác,
TRƯỞNG PHÒNG PHÁT TRIỂN KÊNH PHÂN PHỐI"""

    else:
        subject = f"[ĐẠI THÀNH GROUP] THÔNG BÁO KẾT QUẢ THẨM ĐỊNH HỒ SƠ ĐĂNG KÝ ĐỐI TÁC - {company_name.upper()}"
        decision_statement = "Rất tiếc tại thời điểm hiện tại, Đại Thành chưa thể tiếp nhận và mở rộng mạng lưới phân phối cùng Quý Công ty do quy hoạch địa bàn và yêu cầu khắt khe về hạ tầng dịch vụ kỹ thuật sau bán hàng."
        reasons = negotiation_notes or "Khu vực đăng ký trùng lặp bán kính bảo hộ của Đại lý hiện hữu hoặc điều kiện cơ sở vật chất kỹ thuật/công nợ chưa tương thích với quy chế phân phối hiện hành của Đại Thành."

        full_text = f"""CÔNG TY CỔ PHẦN THIẾT BỊ GIA DỤNG ĐẠI THÀNH
Hà Nội, {now_date}

THƯ THÔNG BÁO KẾT QUẢ THẨM ĐỊNH HỒ SƠ ĐẠI LÝ

Kính gửi: Ban Lãnh đạo {company_name}

Công ty Cổ phần Thiết bị Gia dụng Đại Thành xin gửi lời chào trân trọng và lời cảm ơn chân thành vì sự tin tưởng của Quý Công ty đối với dải sản phẩm gia dụng của Đại Thành.

Hội đồng Thẩm định đã tiến hành rà soát kỹ lưỡng hồ sơ đăng ký phân phối của Quý Công ty. Đại Thành luôn kiên định tôn trọng các cam kết bảo vệ địa bàn độc quyền cho các đại lý hiện hữu cũng như bảo đảm tuyệt đối chất lượng trạm bảo hành phục vụ người tiêu dùng.

Căn cứ vào kết quả khảo sát thực tế và quy hoạch mạng lưới phân phối:
{reasons}

Chúng tôi rất tiếc phải thông báo hiện tại chưa thể tiến hành hợp tác phân phối chính thức với Quý Công ty tại địa bàn đã đăng ký. Hồ sơ của Quý Công ty sẽ được lưu trữ trong Cơ sở dữ liệu Tiềm năng của Đại Thành để ưu tiên xem xét khi có đợt quy hoạch hoặc mở rộng thị trường tiếp theo.

Kính chúc Quý Công ty luôn kinh doanh thuận lợi và gặt hái nhiều thành công!

Trân trọng,
TRƯỞNG PHÒNG PHÁT TRIỂN KÊNH PHÂN PHỐI"""

    return {
        "subject": subject,
        "recipient_name": f"{legal_rep} ({company_name})",
        "salutation": f"Kính gửi: Ban Giám đốc {company_name}",
        "opening_paragraph": f"Công ty Cổ phần Thiết bị Gia dụng Đại Thành xin cảm ơn Quý Công ty đã gửi hồ sơ đăng ký hợp tác phân phối.",
        "assessment_summary": f"Điểm đánh giá tổng hợp: {final_score}/100 ({tier}).",
        "decision_statement": decision_statement,
        "terms_and_conditions": terms if decision != "CHƯA TIẾP TỤC" else reasons,
        "closing_action": "Vui lòng liên hệ Phòng PTKD Đại Thành để tiến hành các bước tiếp theo.",
        "full_letter_content": full_text
    }


def export_pipeline_to_excel(dossiers_list: List[Dict[str, Any]], output_path: Optional[str] = None):
    """
    Exports all partner dossiers to a beautifully formatted Excel (.xlsx) file
    with official Đại Thành corporate design, status colors, and KPI formulas.
    """
    wb = openpyxl.Workbook()

    # Sheet 1: Tổng hợp Danh sách Hồ sơ
    ws1 = wb.active
    ws1.title = "Tổng Hợp Hồ Sơ Đại Lý"
    ws1.views.sheetView[0].showGridLines = True

    # Sheet 2: Chi tiết Đánh giá & Tiêu chuẩn
    ws2 = wb.create_sheet(title="Chi Tiết Thẩm Định")
    ws2.views.sheetView[0].showGridLines = True

    # Styling Palette
    c_primary = "1E3A8A"      # Navy Blue
    c_primary_light = "DBEAFE"# Soft blue
    c_accent = "F59E0B"       # Gold/Amber
    c_border = "CBD5E1"       # Light gray
    c_head_bg = "1E3A8A"
    c_head_fg = "FFFFFF"

    font_title = Font(name="Segoe UI", size=16, bold=True, color="1E3A8A")
    font_subtitle = Font(name="Segoe UI", size=10, italic=True, color="475569")
    font_header = Font(name="Segoe UI", size=10, bold=True, color=c_head_fg)
    font_body = Font(name="Segoe UI", size=10)
    font_bold = Font(name="Segoe UI", size=10, bold=True)
    font_alert = Font(name="Segoe UI", size=10, bold=True, color="DC2626")

    fill_header = PatternFill(start_color=c_head_bg, end_color=c_head_bg, fill_type="solid")
    fill_subhead = PatternFill(start_color="3B82F6", end_color="3B82F6", fill_type="solid")
    fill_row_alt = PatternFill(start_color="F8FAFC", end_color="F8FAFC", fill_type="solid")
    fill_red_flag = PatternFill(start_color="FEE2E2", end_color="FEE2E2", fill_type="solid")
    fill_green_tag = PatternFill(start_color="DCFCE7", end_color="DCFCE7", fill_type="solid")
    fill_blue_tag = PatternFill(start_color="DBEAFE", end_color="DBEAFE", fill_type="solid")

    thin_border = Border(
        left=Side(style='thin', color=c_border),
        right=Side(style='thin', color=c_border),
        top=Side(style='thin', color=c_border),
        bottom=Side(style='thin', color=c_border)
    )

    # -------------------------------------------------------------
    # BUILD SHEET 1: TỔNG HỢP HỒ SƠ
    # -------------------------------------------------------------
    # Brand Header
    ws1["A1"] = "CÔNG TY CỔ PHẦN THIẾT BỊ GIA DỤNG ĐẠI THÀNH"
    ws1["A1"].font = Font(name="Segoe UI", size=12, bold=True, color="64748B")
    ws1["A2"] = "BẢNG TỔNG HỢP THẨM ĐỊNH & PHÊ DUYỆT ĐỐI TÁC PHÂN PHỐI"
    ws1["A2"].font = font_title
    ws1["A3"] = f"Hệ thống AI Agent tự động • Xuất ngày: {datetime.now().strftime('%d/%m/%Y %H:%M')}"
    ws1["A3"].font = font_subtitle

    headers_s1 = [
        "Mã Hồ Sơ", "Tên Pháp Nhân Đối Tác", "Mã Số Thuế", "Khu Vực", "Tỉnh/Thành Phố",
        "Cam Kết Doanh Số (VNĐ)", "Thời Hạn Nợ (Ngày)", "Hạn Mức Đề Xuất (VNĐ)",
        "Số Thợ KTV", "Điểm Đánh Giá", "Xếp Hạng Tier", "Cảnh Báo Cam Kết Ảo",
        "Trạng Thái Địa Bàn", "Quyết Định Phê Duyệt"
    ]

    start_row = 5
    for col_idx, h in enumerate(headers_s1, 1):
        cell = ws1.cell(row=start_row, column=col_idx, value=h)
        cell.font = font_header
        cell.fill = fill_header
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = thin_border
    ws1.row_dimensions[start_row].height = 28

    curr_row = start_row + 1
    for d in dossiers_list:
        intake = d.get("intake_data", {})
        legal = intake.get("legal_entity", {})
        loc = intake.get("location_logistics", {})
        comm = intake.get("commercial_commitment", {})
        tech = intake.get("technical_service", {})
        fin = intake.get("financial_credit", {})

        score_res = d.get("score_result", {})
        comp_res = d.get("compliance_result", {})
        approval = d.get("approval_result", {})

        is_phantom = score_res.get("is_phantom_commitment", False)
        tier = score_res.get("tier", "Chưa xếp")
        final_score = score_res.get("final_score", 0)
        decision = approval.get("decision", "Chưa duyệt")

        # Geofence status string
        geofence_str = "Hợp lệ (>3.5km)"
        if comp_res.get("radius_violation_partner"):
            geofence_str = f"Vi phạm ({comp_res['radius_violation_partner'].get('distance_km')}km)"
        elif comp_res.get("exclusive_district_conflict"):
            geofence_str = "Trùng quận độc quyền"

        row_vals = [
            d.get("dossier_id", ""),
            legal.get("company_name", ""),
            legal.get("tax_id", ""),
            legal.get("region", ""),
            loc.get("province", ""),
            comm.get("committed_monthly_revenue", 0),
            fin.get("requested_debt_days", 0),
            fin.get("requested_credit_limit", 0),
            tech.get("technician_count", 0),
            final_score,
            tier,
            "CẢNH BÁO ĐỎ" if is_phantom else "An toàn",
            geofence_str,
            decision
        ]

        for c_idx, val in enumerate(row_vals, 1):
            cell = ws1.cell(row=curr_row, column=c_idx, value=val)
            cell.font = font_body
            cell.border = thin_border
            cell.alignment = Alignment(vertical="center")

            # Alternate row background
            if curr_row % 2 == 0:
                cell.fill = fill_row_alt

            # Formatting
            if c_idx in [6, 8]:  # Currency
                cell.number_format = '#,##0 "VNĐ"'
                cell.alignment = Alignment(horizontal="right", vertical="center")
            elif c_idx in [1, 3, 4, 7, 9, 10]:
                cell.alignment = Alignment(horizontal="center", vertical="center")
            elif c_idx == 11:  # Tier
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.font = font_bold
                if tier == "Tier A":
                    cell.fill = fill_green_tag
                elif tier == "Tier B":
                    cell.fill = fill_blue_tag
                elif tier == "Tier D":
                    cell.fill = fill_red_flag
            elif c_idx == 12:  # Phantom flag
                cell.alignment = Alignment(horizontal="center", vertical="center")
                if is_phantom:
                    cell.fill = fill_red_flag
                    cell.font = font_alert
            elif c_idx == 14:  # Decision
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.font = font_bold

        ws1.row_dimensions[curr_row].height = 22
        curr_row += 1

    # Auto-adjust column widths
    for col in ws1.columns:
        max_len = max(len(str(cell.value or '')) for cell in col)
        col_letter = get_column_letter(col[0].column)
        ws1.column_dimensions[col_letter].width = max(max_len + 4, 12)

    # -------------------------------------------------------------
    # BUILD SHEET 2: CHI TIẾT THẨM ĐỊNH 4 NHÓM TIÊU CHÍ
    # -------------------------------------------------------------
    ws2["A1"] = "CHI TIẾT THẨM ĐỊNH MA TRẬN 100 ĐIỂM & RỦI RO NGHIỆP VỤ"
    ws2["A1"].font = font_title
    ws2["A2"] = "Dữ liệu phục vụ lưu trữ kiểm toán nội bộ và thẩm tra thực địa"
    ws2["A2"].font = font_subtitle

    headers_s2 = [
        "Mã HS", "Tên Pháp Nhân", "Thương Mại (30đ)", "Bảo Hành (25đ)",
        "Tài Chính (25đ)", "Vị Trí Kho (20đ)", "Điểm Phạt Bẫy Ảo", "Điểm Phạt Địa Bàn",
        "Tổng Điểm Cuối", "Chi Tiết Điểm Thẩm Định Dịch Vụ Bảo Hành", "Chi Tiết Thẩm Định Tài Chính & CIC"
    ]

    start_row_s2 = 4
    for c_idx, h in enumerate(headers_s2, 1):
        cell = ws2.cell(row=start_row_s2, column=c_idx, value=h)
        cell.font = font_header
        cell.fill = fill_subhead
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = thin_border
    ws2.row_dimensions[start_row_s2].height = 26

    r_s2 = start_row_s2 + 1
    for d in dossiers_list:
        intake = d.get("intake_data", {})
        legal = intake.get("legal_entity", {})
        score_res = d.get("score_result", {})
        cats = score_res.get("categories", {})

        comm_cat = cats.get("commercial", {})
        warr_cat = cats.get("warranty_technical", {})
        fin_cat = cats.get("financial_legal", {})
        loc_cat = cats.get("location_logistics", {})

        warr_desc = "; ".join(warr_cat.get("details", []))
        fin_desc = "; ".join(fin_cat.get("details", []))

        s2_vals = [
            d.get("dossier_id", ""),
            legal.get("company_name", ""),
            f"{comm_cat.get('score', 0)}/30",
            f"{warr_cat.get('score', 0)}/25",
            f"{fin_cat.get('score', 0)}/25",
            f"{loc_cat.get('score', 0)}/20",
            f"-{score_res.get('phantom_penalty', 0)}đ" if score_res.get('phantom_penalty', 0) > 0 else "0",
            f"-{score_res.get('total_penalty', 0) - score_res.get('phantom_penalty', 0)}đ",
            score_res.get("final_score", 0),
            warr_desc,
            fin_desc
        ]

        for c_idx, val in enumerate(s2_vals, 1):
            cell = ws2.cell(row=r_s2, column=c_idx, value=val)
            cell.font = font_body
            cell.border = thin_border
            cell.alignment = Alignment(vertical="center")
            if c_idx in [1, 3, 4, 5, 6, 7, 8, 9]:
                cell.alignment = Alignment(horizontal="center", vertical="center")
            if c_idx == 9:
                cell.font = font_bold

        ws2.row_dimensions[r_s2].height = 24
        r_s2 += 1

    for col in ws2.columns:
        max_len = max(len(str(cell.value or '')) for cell in col)
        col_letter = get_column_letter(col[0].column)
        ws2.column_dimensions[col_letter].width = min(max(max_len + 4, 12), 45)

    if output_path:
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        wb.save(output_path)
        return output_path
    else:
        import io
        bio = io.BytesIO()
        wb.save(bio)
        bio.seek(0)
        return bio

