"""
Pipeline Manager module:
Orchestrates the 6-step lifecycle State Machine for partner dossiers.
Manages persistent storage in pipeline_database.json and provides CRUD & action handlers.
"""

import os
import json
import uuid
from typing import Dict, Any, List, Optional
from datetime import datetime

from agent.extractor import normalize_intake_data, parse_unstructured_text, extract_text_from_file
from agent.compliance_checker import run_compliance_check
from agent.verification_router import generate_verification_tickets, update_verification_ticket
from agent.scoring_engine import calculate_dossier_score
from agent.dossier_generator import (
    generate_strategic_assessment,
    generate_conditions_precedent,
    generate_draft_response_letter,
    export_pipeline_to_excel
)

import tempfile

def _resolve_pipeline_dir() -> str:
    is_cloud_serverless = bool(
        os.environ.get("VERCEL") or
        os.environ.get("AWS_LAMBDA_FUNCTION_NAME") or
        os.environ.get("VERCEL_ENV")
    )
    if is_cloud_serverless:
        target = os.path.join(tempfile.gettempdir(), "partneriq_data")
        os.makedirs(target, exist_ok=True)
        return target
    default_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
    try:
        os.makedirs(default_dir, exist_ok=True)
        return default_dir
    except Exception:
        target = os.path.join(tempfile.gettempdir(), "partneriq_data")
        os.makedirs(target, exist_ok=True)
        return target

DATA_DIR = _resolve_pipeline_dir()
DB_FILE = os.path.join(DATA_DIR, "pipeline_database.json")


def load_database() -> Dict[str, Any]:
    """Loads dossiers from pipeline_database.json; seeds defaults if missing or empty."""
    if os.path.exists(DB_FILE):
        try:
            with open(DB_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                if data and "dossiers" in data and len(data["dossiers"]) > 0:
                    return data
        except Exception:
            pass

    # Initialize with default seed dossiers
    default_db = seed_sample_dossiers()
    save_database(default_db)
    return default_db


def save_database(data: Dict[str, Any]) -> bool:
    """Persists data to pipeline_database.json."""
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(DB_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True
    except Exception as e:
        print(f"Error saving pipeline DB: {e}")
        return False


def get_all_dossiers() -> List[Dict[str, Any]]:
    """Returns list of all dossiers sorted by created_at descending."""
    db = load_database()
    dossiers = db.get("dossiers", [])
    return sorted(dossiers, key=lambda x: x.get("created_at", ""), reverse=True)


def get_dossier_by_id(dossier_id: str) -> Optional[Dict[str, Any]]:
    """Retrieves a single dossier by ID."""
    db = load_database()
    for d in db.get("dossiers", []):
        if d.get("dossier_id") == dossier_id:
            return d
    return None


def create_dossier(intake_data: Dict[str, Any], source_type: str = "ONLINE_FORM") -> Dict[str, Any]:
    """
    Creates a new partner dossier and automatically runs Step 1 through Step 4.
    """
    db = load_database()
    next_num = len(db.get("dossiers", [])) + 1
    dossier_id = f"HS-DT-{datetime.now().strftime('%y%m')}-{next_num:03d}"

    normalized_intake = normalize_intake_data(intake_data)
    normalized_intake["source_type"] = source_type

    # Step 2: Compliance Check
    compliance_res = run_compliance_check(normalized_intake)

    # Step 3: Verification Tickets initialization
    verification_tickets = generate_verification_tickets(normalized_intake, compliance_res)

    # Step 4: Scoring
    score_res = calculate_dossier_score(normalized_intake, compliance_res, verification_tickets)

    # Step 5: Preliminary Strategic Assessment
    strategic_assessment = generate_strategic_assessment(
        normalized_intake, compliance_res, score_res, verification_tickets
    )

    # Step 6: Initial Conditions Precedent and Draft Letter based on preliminary recommendation
    preliminary_decision = strategic_assessment.get("preliminary_decision", "BỔ SUNG ĐIỀU KIỆN")
    conditions = generate_conditions_precedent(normalized_intake, preliminary_decision, score_res, compliance_res)
    draft_letter = generate_draft_response_letter(
        normalized_intake, preliminary_decision, "", score_res, compliance_res, conditions
    )

    dossier = {
        "dossier_id": dossier_id,
        "current_step": 4,  # Ready for human review at Step 5
        "status": "AWAITING_APPROVAL",
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "intake_data": normalized_intake,
        "compliance_result": compliance_res,
        "verification_tickets": verification_tickets,
        "score_result": score_res,
        "strategic_assessment": strategic_assessment,
        "conditions_precedent": conditions,
        "approval_result": {
            "decision": preliminary_decision,
            "decision_by": "Chưa phê duyệt",
            "negotiation_notes": "",
            "approved_at": None
        },
        "response_letter": draft_letter
    }

    db["dossiers"].append(dossier)
    save_database(db)
    return dossier


def update_verification_and_rescore(dossier_id: str, dept_code: str, update_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Updates field verification findings for Step 3, re-runs Step 4 scoring,
    and recalculates strategic assessment.
    """
    db = load_database()
    dossier = None
    for d in db.get("dossiers", []):
        if d.get("dossier_id") == dossier_id:
            dossier = d
            break

    if not dossier:
        return None

    # Update ticket
    cur_tickets = dossier.get("verification_tickets", {})
    updated_tickets = update_verification_ticket(cur_tickets, dept_code, update_data)
    dossier["verification_tickets"] = updated_tickets

    # Re-calculate score with verified findings
    score_res = calculate_dossier_score(
        dossier["intake_data"],
        dossier["compliance_result"],
        updated_tickets
    )
    dossier["score_result"] = score_res

    # Re-generate strategic assessment
    strat = generate_strategic_assessment(
        dossier["intake_data"],
        dossier["compliance_result"],
        score_res,
        updated_tickets
    )
    dossier["strategic_assessment"] = strat
    dossier["updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    save_database(db)
    return dossier


def submit_approval_decision(
    dossier_id: str,
    decision: str,
    negotiation_notes: str,
    approver_name: str = "Trưởng phòng PTKD"
) -> Optional[Dict[str, Any]]:
    """
    Records Head of BD decision (Step 5) and generates final Letter & Conditions (Step 6).
    """
    db = load_database()
    dossier = None
    for d in db.get("dossiers", []):
        if d.get("dossier_id") == dossier_id:
            dossier = d
            break

    if not dossier:
        return None

    conditions = generate_conditions_precedent(
        dossier["intake_data"],
        decision,
        dossier["score_result"],
        dossier["compliance_result"]
    )

    letter = generate_draft_response_letter(
        dossier["intake_data"],
        decision,
        negotiation_notes,
        dossier["score_result"],
        dossier["compliance_result"],
        conditions
    )

    dossier["approval_result"] = {
        "decision": decision,
        "decision_by": approver_name,
        "negotiation_notes": negotiation_notes,
        "approved_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    dossier["conditions_precedent"] = conditions
    dossier["response_letter"] = letter
    dossier["current_step"] = 6
    dossier["status"] = "COMPLETED"
    dossier["updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    save_database(db)
    return dossier


def delete_dossier(dossier_id: str) -> bool:
    """Deletes a dossier from the database."""
    db = load_database()
    initial_len = len(db.get("dossiers", []))
    db["dossiers"] = [d for d in db.get("dossiers", []) if d.get("dossier_id") != dossier_id]
    if len(db["dossiers"]) < initial_len:
        save_database(db)
        return True
    return False


def seed_sample_dossiers() -> Dict[str, Any]:
    """Generates the 4 core business benchmark test scenarios."""
    db = {"dossiers": []}

    # Case 1: Tier A Chuẩn - Minh Quang Đà Nẵng
    data1 = {
        "legal_entity": {
            "company_name": "Công ty TNHH Thương Mại & Kỹ Thuật Minh Quang",
            "tax_id": "0402123456",
            "legal_rep": "Trần Minh Quang",
            "phone": "0905999888",
            "email": "minhquang.danang@gmail.com",
            "established_year": 2018,
            "region": "KV2"
        },
        "location_logistics": {
            "address": "450 Đường Điện Biên Phủ, Phường Thanh Khê Đông, Quận Thanh Khê, Đà Nẵng",
            "district": "Quận Thanh Khê",
            "province": "Đà Nẵng",
            "latitude": 16.0685,
            "longitude": 108.1895,
            "store_front_width_m": 12.0,
            "warehouse_area_m2": 200.0,
            "truck_accessible": True
        },
        "commercial_commitment": {
            "committed_monthly_revenue": 1400000000,
            "product_lines": ["Bếp từ", "Máy lọc nước", "Bình nước nóng"],
            "target_channels": ["Đại lý cấp 2", "Dự án căn hộ", "Bán lẻ"],
            "industry_experience_years": 6
        },
        "technical_service": {
            "technician_count": 3,
            "workshop_area_m2": 35.0,
            "sla_commit_hours": 24,
            "spare_parts_stock": True
        },
        "financial_credit": {
            "requested_credit_limit": 500000000,
            "requested_debt_days": 30,
            "has_bank_guarantee": True,
            "charter_capital": 6000000000
        }
    }

    # Case 2: Bẫy Cam Kết Ảo - Tân Phát Gia Dụng
    data2 = {
        "legal_entity": {
            "company_name": "Công ty Cổ phần Thương mại Tổng hợp Tân Phát",
            "tax_id": "0109887766",
            "legal_rep": "Lê Văn Phát",
            "phone": "0915667788",
            "email": "tanphat.appliance@gmail.com",
            "established_year": 2021,
            "region": "KV1"
        },
        "location_logistics": {
            "address": "88 Đường Tam Trinh, Phường Yên Sở, Quận Hoàng Mai, Hà Nội",
            "district": "Quận Hoàng Mai",
            "province": "Hà Nội",
            "latitude": 20.9850,
            "longitude": 105.8650,
            "store_front_width_m": 7.0,
            "warehouse_area_m2": 90.0,
            "truck_accessible": True
        },
        "commercial_commitment": {
            "committed_monthly_revenue": 2500000000,  # Cam kết 2.5 tỷ/tháng rất khủng
            "product_lines": ["Bếp từ", "Máy lọc nước", "Bình nước nóng", "Quạt điều hòa"],
            "target_channels": ["Đại lý cấp 2"],
            "industry_experience_years": 2
        },
        "technical_service": {
            "technician_count": 0,  # 0 thợ kỹ thuật!
            "workshop_area_m2": 0.0,  # Không có xưởng bảo hành!
            "sla_commit_hours": 72,
            "spare_parts_stock": False
        },
        "financial_credit": {
            "requested_credit_limit": 1200000000,
            "requested_debt_days": 60,  # Đòi nợ 60 ngày vượt trần cấm!
            "has_bank_guarantee": False,
            "charter_capital": 2000000000
        }
    }

    # Case 3: Xung Đột Bán Kính & Địa Bàn - Điện Máy Sao Mai (Cầu Giấy)
    data3 = {
        "legal_entity": {
            "company_name": "Công ty TNHH Điện Máy Sao Mai",
            "tax_id": "0108771122",
            "legal_rep": "Hoàng Sao Mai",
            "phone": "0904332211",
            "email": "dienmay.saomai@gmail.com",
            "established_year": 2019,
            "region": "KV1"
        },
        "location_logistics": {
            "address": "250 Đường Cầu Giấy, Phường Dịch Vọng, Quận Cầu Giấy, Hà Nội",
            "district": "Quận Cầu Giấy",
            "province": "Hà Nội",
            "latitude": 21.0345,
            "longitude": 105.7980,  # Cách đại lý Á Châu chỉ ~0.5 km!
            "store_front_width_m": 9.0,
            "warehouse_area_m2": 110.0,
            "truck_accessible": True
        },
        "commercial_commitment": {
            "committed_monthly_revenue": 1000000000,
            "product_lines": ["Bếp từ", "Máy lọc nước"],
            "target_channels": ["Bán lẻ", "Đại lý cấp 2"],
            "industry_experience_years": 4
        },
        "technical_service": {
            "technician_count": 2,
            "workshop_area_m2": 20.0,
            "sla_commit_hours": 48,
            "spare_parts_stock": True
        },
        "financial_credit": {
            "requested_credit_limit": 400000000,
            "requested_debt_days": 30,
            "has_bank_guarantee": False,
            "charter_capital": 3000000000
        }
    }

    # Case 4: Nợ Xấu / Trùng MST Blacklist - Toàn Cầu Tech
    data4 = {
        "legal_entity": {
            "company_name": "Công ty TNHH Đầu Tư Toàn Cầu Mới",
            "tax_id": "0108999888",  # Trùng MST blacklist nợ 850 triệu
            "legal_rep": "Nguyễn Văn Thắng",
            "phone": "0912345678",
            "email": "toancau.new@gmail.com",
            "established_year": 2024,
            "region": "KV1"
        },
        "location_logistics": {
            "address": "15 Đường Giải Phóng, Phường Đồng Tâm, Quận Hai Bà Trưng, Hà Nội",
            "district": "Quận Hai Bà Trưng",
            "province": "Hà Nội",
            "latitude": 21.0020,
            "longitude": 105.8420,
            "store_front_width_m": 8.0,
            "warehouse_area_m2": 100.0,
            "truck_accessible": True
        },
        "commercial_commitment": {
            "committed_monthly_revenue": 1200000000,
            "product_lines": ["Bình nước nóng", "Máy lọc nước"],
            "target_channels": ["Bán buôn"],
            "industry_experience_years": 8
        },
        "technical_service": {
            "technician_count": 1,
            "workshop_area_m2": 15.0,
            "sla_commit_hours": 48,
            "spare_parts_stock": False
        },
        "financial_credit": {
            "requested_credit_limit": 600000000,
            "requested_debt_days": 45,
            "has_bank_guarantee": False,
            "charter_capital": 2500000000
        }
    }

    raw_cases = [
        (data1, "ONLINE_FORM", "HS-DT-2601-001"),
        (data2, "FILE_UPLOAD", "HS-DT-2601-002"),
        (data3, "ONLINE_FORM", "HS-DT-2601-003"),
        (data4, "ONLINE_FORM", "HS-DT-2601-004")
    ]

    for intake, src, fixed_id in raw_cases:
        norm = normalize_intake_data(intake)
        norm["source_type"] = src

        comp = run_compliance_check(norm)
        tickets = generate_verification_tickets(norm, comp)
        score = calculate_dossier_score(norm, comp, tickets)
        strat = generate_strategic_assessment(norm, comp, score, tickets)

        prelim_decision = strat.get("preliminary_decision", "BỔ SUNG ĐIỀU KIỆN")
        conds = generate_conditions_precedent(norm, prelim_decision, score, comp)
        letter = generate_draft_response_letter(norm, prelim_decision, "", score, comp, conds)

        dossier = {
            "dossier_id": fixed_id,
            "current_step": 5 if fixed_id != "HS-DT-2601-001" else 6,
            "status": "AWAITING_APPROVAL" if fixed_id != "HS-DT-2601-001" else "COMPLETED",
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "intake_data": norm,
            "compliance_result": comp,
            "verification_tickets": tickets,
            "score_result": score,
            "strategic_assessment": strat,
            "conditions_precedent": conds,
            "approval_result": {
                "decision": prelim_decision if fixed_id != "HS-DT-2601-001" else "TIẾP TỤC",
                "decision_by": "Chưa phê duyệt" if fixed_id != "HS-DT-2601-001" else "Trưởng phòng PTKD Nguyễn Hải Đăng",
                "negotiation_notes": "Hồ sơ đáp ứng chuẩn mực phân phối Cấp 1, chấp thuận bảo lãnh ngân hàng." if fixed_id == "HS-DT-2601-001" else "",
                "approved_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S") if fixed_id == "HS-DT-2601-001" else None
            },
            "response_letter": letter
        }
        db["dossiers"].append(dossier)

    return db

