"""
B5. Feedback Engine & Scoped Reprocessing (DataIQ)
Implements:
1. Multi-level feedback collection (Report, Finding, Cell/Row).
2. Scoped reprocessing (only re-runs affected stages).
3. Non-mechanical verification (Fact-checks feedback against raw ground truth).
4. Conflict resolution & Manual Force Override with audit trail.
5. Version management (v1, v2, v3...) and Visual Diff engine.
6. Lessons Learned extraction and workspace persistence.
"""

import json
import re
from datetime import datetime
from typing import Dict, Any, List, Tuple, Optional
import pandas as pd
import numpy as np

from partneriq.repository import (
    get_job, get_run, create_run, add_change_logs, add_findings,
    add_feedback, get_feedbacks, update_feedback_status, add_lesson,
    log_audit, get_active_lessons, get_runs_by_job, update_job_status
)
from partneriq.core.data_agent.planner import create_processing_plan
from partneriq.core.data_agent.processor import execute_data_processing
from partneriq.core.data_agent.analyzer import analyze_business_data, generate_executive_report
from agent.llm_client import call_gemini


REPROCESS_PLAN_PROMPT = """
Bạn là Trợ lý AI Tái Xử Lý Dữ Liệu Doanh Nghiệp Cấp Cao.
Người dùng vừa gửi các phản hồi hiệu chỉnh đối với kết quả xử lý dữ liệu hiện tại.

NHIỆM VỤ CỦA BẠN:
Đọc Bối cảnh ban đầu, Kế hoạch cũ và Danh sách các phản hồi của người dùng.
Đề xuất Kế hoạch Điều chỉnh (Adjustment Plan) dưới dạng JSON:
{
  "summary_of_changes": "Tóm lược các điểm Agent sẽ sửa đổi theo phản hồi.",
  "adjust_column_mappings": [
    {"column_name": "col", "new_business_role": "ROLE", "reason": "Lý do đổi role"}
  ],
  "adjust_cleaning_rules": {
    "override_cell_values": [
      {"dataset": "ds", "row": 1, "col": "col", "value": "val", "reason": "Người dùng chỉ đạo ghi đè"}
    ]
  },
  "adjust_analysis_focus": "Điểm cần tập trung phân tích lại trong báo cáo"
}
"""


def verify_feedback_against_ground_truth(
    feedback: Dict[str, Any],
    raw_datasets: Dict[str, pd.DataFrame]
) -> Tuple[bool, str, Dict[str, Any]]:
    """
    Verifies user feedback against raw ground-truth data.
    If feedback makes an assertion that directly contradicts the raw file,
    flags as CONFLICT with concrete evidence coordinates.
    Returns: (is_valid, explanation_note, conflict_evidence)
    """
    cat = feedback.get("error_category", "")
    comment = feedback.get("user_comment", "").lower()
    expected = str(feedback.get("expected_value") or "").strip()
    target_ref = feedback.get("target_ref", "")

    # Check 1: Cell-level verification
    if feedback.get("level") == "CELL" and target_ref:
        # target_ref format: "row:X,col:Y" or "dataset:Z,row:X,col:Y"
        row_match = re.search(r'row:(\d+)', target_ref)
        col_match = re.search(r'col:([^\s,]+)', target_ref)

        if row_match and col_match:
            r_idx = int(row_match.group(1)) - 1  # 0-indexed
            c_name = col_match.group(1)

            for ds_name, df in raw_datasets.items():
                if c_name in df.columns and 0 <= r_idx < len(df):
                    raw_val = df.at[r_idx, c_name]
                    # If user claims raw value was different from what file actually has
                    if expected and str(raw_val).strip() != expected:
                        # Check if user says file already has value X, but file has Y
                        if "gốc là" in comment or "file ghi là" in comment:
                            evidence = {
                                "dataset": ds_name,
                                "row": r_idx + 1,
                                "col": c_name,
                                "actual_raw_value": str(raw_val),
                                "claimed_value": expected
                            }
                            return False, f"Mâu thuẫn dữ liệu gốc: Tại dòng {r_idx + 1}, cột '{c_name}', giá trị thực tế trong tệp tải lên là '{raw_val}', khác với giá trị người dùng khẳng định là '{expected}'.", evidence

    # Check 2: Total Revenue claim contradiction
    # E.g. User says "Tổng doanh thu phải là X tỷ", but sum of all rows is completely different
    num_claims = re.findall(r'(\d+[\.,]?\d*)\s*(tỷ|triệu|nghìn|tr|ty)', comment)
    if num_claims and ("tổng doanh thu" in comment or "tổng tiền" in comment):
        val_str, unit = num_claims[0]
        val_num = float(val_str.replace(",", "."))
        mult = 1_000_000_000 if "tỷ" in unit or "ty" in unit else (1_000_000 if "triệu" in unit or "tr" in unit else 1_000)
        claimed_total = val_num * mult

        # Sum raw numeric totals
        for ds_name, df in raw_datasets.items():
            for c in ["Thanh_Tien", "Doanh_Thu", "total", "amount"]:
                if c in df.columns:
                    raw_sum = pd.to_numeric(df[c], errors="coerce").fillna(0).sum()
                    if raw_sum > 0 and abs(raw_sum - claimed_total) / max(raw_sum, 1) > 0.3:
                        evidence = {
                            "dataset": ds_name,
                            "column": c,
                            "total_raw_rows": len(df),
                            "actual_raw_sum": float(raw_sum),
                            "claimed_total": claimed_total
                        }
                        return False, f"Mâu thuẫn với dữ liệu gốc: Tổng cộng toàn bộ {len(df)} dòng cột '{c}' trong tệp chỉ đạt {raw_sum:,.0f} đ, khác biệt lớn so với con số {claimed_total:,.0f} đ trong phản hồi.", evidence

    return True, "Phản hồi hợp lệ và phù hợp với cơ sở dữ liệu thực chứng.", {}


def compute_version_diff(
    old_run: Dict[str, Any],
    new_clean_datasets: Dict[str, pd.DataFrame],
    new_findings: List[Dict[str, Any]],
    new_kpis: Dict[str, Any]
) -> Dict[str, Any]:
    """Computes difference between two runs (v1 vs v2)."""
    old_preview = old_run.get("clean_data_preview", {})
    old_kpis = old_preview.get("kpis", {})

    old_rev = old_kpis.get("adjusted_revenue", 0)
    new_rev = new_kpis.get("adjusted_revenue", 0)
    rev_delta = new_rev - old_rev

    old_findings_count = old_kpis.get("total_findings_count", 0)
    new_findings_count = new_kpis.get("total_findings_count", 0)

    return {
        "kpi_diff": {
            "old_adjusted_revenue": old_rev,
            "new_adjusted_revenue": new_rev,
            "revenue_delta": rev_delta,
            "old_findings_count": old_findings_count,
            "new_findings_count": new_findings_count,
            "findings_delta": new_findings_count - old_findings_count
        },
        "version_comparison": {
            "from_version": old_run.get("version", 1),
            "to_version": old_run.get("version", 1) + 1,
            "summary_message": f"Doanh thu hiệu chỉnh thay đổi {rev_delta:+,.0f} đ; Số phát hiện rủi ro từ {old_findings_count} -> {new_findings_count}."
        }
    }


def execute_scoped_reprocessing(
    job_id: str,
    raw_datasets: Optional[Dict[str, pd.DataFrame]] = None,
    feedbacks_list: Optional[List[Dict[str, Any]]] = None,
    workspace_id: str = "ws-default",
    trigger_type: str = "REPROCESS",
    user_name: str = "staff"
) -> Dict[str, Any]:
    """
    Executes scoped reprocessing based on user feedback:
    1. Evaluates feedbacks against ground truth.
    2. Identifies affected stages.
    3. Re-runs affected pipeline stages.
    4. Generates new version (v2, v3...).
    5. Extracts Lessons Learned.
    """
    from partneriq.core.data_agent.reader import read_all_job_files
    from partneriq.repository import get_job_files

    job = get_job(job_id)
    if not job:
        raise ValueError(f"Không tìm thấy tác vụ {job_id}")

    if not raw_datasets:
        files = get_job_files(job_id)
        raw_datasets, _ = read_all_job_files(files)

    feedbacks_list = feedbacks_list or []

    old_run = get_run(f"{job_id}-v{job.get('current_run_version', 1)}")
    if not old_run:
        # Fallback to latest run
        runs = get_runs_by_job(job_id)
        old_run = runs[-1] if runs else {}

    current_ver = old_run.get("version", 1)
    new_ver = current_ver + 1

    # Check max rounds limit from workspace
    from partneriq.repository import get_workspace
    ws = get_workspace(workspace_id)
    max_rounds = ws.get("config", {}).get("max_reprocess_rounds", 5) if ws else 5
    if new_ver > max_rounds:
        raise ValueError(f"Tác vụ đã đạt số vòng xử lý lại tối đa ({max_rounds} vòng). Vui lòng nghiệm thu hoặc tạo tác vụ mới.")

    update_job_status(job_id, "REPROCESSING", f"Đang tái xử lý phiên bản v{new_ver}", user_name=user_name)

    applied_feedbacks = []
    conflicted_feedbacks = []
    lessons_to_add = []

    # 1. Fact-check feedbacks
    for fb in feedbacks_list:
        is_valid, note, evidence = verify_feedback_against_ground_truth(fb, raw_datasets)
        fb_id = fb.get("id") or add_feedback(fb)

        if not is_valid and fb.get("status") != "OVERRIDDEN":
            # Conflict detected!
            update_feedback_status(
                feedback_id=fb_id,
                status="REJECTED_CONFLICT",
                resolution_notes=note,
                conflict_evidence=evidence
            )
            conflicted_feedbacks.append({
                "feedback_id": fb_id,
                "error_category": fb.get("error_category"),
                "user_comment": fb.get("user_comment"),
                "reason": note,
                "evidence": evidence
            })
        else:
            # Valid or User-Overridden
            update_feedback_status(
                feedback_id=fb_id,
                status="APPLIED",
                resolution_notes="Đã áp dụng điều chỉnh vào phiên bản mới."
            )
            applied_feedbacks.append(fb)

            # Check if this qualifies as a Lesson Learned
            cat = fb.get("error_category", "")
            comment = fb.get("user_comment", "")
            if cat in ["Hiểu sai ý nghĩa cột", "Khác"] and len(comment) > 10:
                rule_key = f"fb_rule_{fb.get('target_ref') or 'general'}"
                lessons_to_add.append({
                    "category": "COLUMN_SEMANTICS" if "cột" in comment.lower() else "BUSINESS_RULE",
                    "rule_key": rule_key,
                    "rule_content": comment,
                    "source_feedback_id": fb_id
                })

    # Save new lessons
    for l in lessons_to_add:
        add_lesson(
            workspace_id=workspace_id,
            category=l["category"],
            rule_key=l["rule_key"],
            rule_content=l["rule_content"],
            source_job_id=job_id,
            source_feedback_id=l.get("source_feedback_id"),
            created_by=user_name
        )

    # 2. Determine Scope
    needs_replanning = any(fb.get("error_category") == "Hiểu sai ý nghĩa cột" for fb in applied_feedbacks)
    active_lessons = get_active_lessons(workspace_id)

    # 3. Execution based on scope
    new_run_id = f"{job_id}-v{new_ver}"
    old_plan = old_run.get("plan_json", {})
    profiling = old_run.get("profiling_json", {})

    if needs_replanning or not old_plan:
        new_plan, plan_source = create_processing_plan(
            business_context=job.get("business_context", {}),
            problem_statement=f"{job.get('problem_statement')} (Lưu ý phản hồi: {applied_feedbacks[0].get('user_comment', '') if applied_feedbacks else ''})",
            goals=job.get("goals", []),
            profiling_summary=profiling,
            column_descriptions=job.get("column_descriptions", {}),
            lessons=active_lessons
        )
    else:
        new_plan = old_plan
        plan_source = old_run.get("ai_source_badge", "GEMINI_AI")

    # Apply cell-level overrides from applied feedbacks
    for fb in applied_feedbacks:
        if fb.get("level") == "CELL" and fb.get("expected_value"):
            target = fb.get("target_ref", "")
            r_m = re.search(r'row:(\d+)', target)
            c_m = re.search(r'col:([^\s,]+)', target)
            if r_m and c_m:
                r_i = int(r_m.group(1)) - 1
                c_n = c_m.group(1)
                for ds_name in raw_datasets:
                    if c_n in raw_datasets[ds_name].columns and 0 <= r_i < len(raw_datasets[ds_name]):
                        raw_datasets[ds_name].at[r_i, c_n] = fb.get("expected_value")

    # Re-run processor
    clean_datasets, change_logs, proc_metrics = execute_data_processing(
        raw_datasets=raw_datasets,
        plan=new_plan,
        run_id=new_run_id,
        job_id=job_id,
        workspace_id=workspace_id
    )
    add_change_logs(change_logs)

    # Re-run analyzer
    findings, kpis, chart_data = analyze_business_data(
        clean_datasets=clean_datasets,
        change_logs=change_logs,
        plan=new_plan,
        problem_statement=job.get("problem_statement", ""),
        business_context=job.get("business_context", {}),
        run_id=new_run_id,
        job_id=job_id,
        workspace_id=workspace_id
    )
    add_findings(findings)

    # Re-run report generator
    report_md, report_sections, rep_source = generate_executive_report(
        problem_statement=job.get("problem_statement", ""),
        business_context=job.get("business_context", {}),
        findings=findings,
        kpis=kpis,
        change_logs=change_logs
    )

    # 4. Summarize changes
    diff_data = compute_version_diff(old_run, clean_datasets, findings, kpis)

    summary_applied = f"Đã áp dụng {len(applied_feedbacks)} phản hồi người dùng. Tái xử lý thành công phiên bản v{new_ver}."
    summary_conflicts = ""
    if conflicted_feedbacks:
        summary_conflicts = f"Có {len(conflicted_feedbacks)} phản hồi mâu thuẫn dữ liệu gốc chưa được áp dụng (bạn có thể bấm 'Ghi đè thủ công' nếu muốn cưỡng chế)."

    full_reprocess_summary = f"{summary_applied} {summary_conflicts}".strip()

    # Clean preview for UI
    first_df = list(clean_datasets.values())[0] if clean_datasets else pd.DataFrame()
    preview_data = {
        "columns": list(first_df.columns),
        "rows": first_df.head(100).to_dict(orient="records"),
        "kpis": kpis,
        "chart_data": chart_data
    }

    # 5. Create new run record
    new_run = create_run(
        run_id=new_run_id,
        job_id=job_id,
        workspace_id=workspace_id,
        version=new_ver,
        trigger_type=trigger_type,
        gatekeeper_decision="CAN_PROCESS",
        gatekeeper_notes="Tái xử lý thành công theo chỉ đạo phản hồi.",
        plan_json=new_plan,
        profiling_json=profiling,
        clean_data_path="",
        clean_data_preview=preview_data,
        report_markdown=report_md,
        report_sections_json=report_sections,
        ai_source_badge=rep_source,
        diff_summary_json=diff_data,
        reprocess_summary=full_reprocess_summary
    )

    update_job_status(job_id, "READY_FOR_REVIEW", f"Sẵn sàng đánh giá (v{new_ver})", user_name=user_name)

    log_audit(
        workspace_id=workspace_id,
        action="REPROCESS_JOB",
        target_type="JOB",
        target_id=job_id,
        user_name=user_name,
        before_state={"version": current_ver},
        after_state={"version": new_ver, "applied_feedbacks": len(applied_feedbacks), "conflicts": len(conflicted_feedbacks)},
        details=f"Tái xử lý phiên bản v{new_ver}: Áp dụng {len(applied_feedbacks)} phản hồi, phát hiện {len(conflicted_feedbacks)} mâu thuẫn."
    )

    return {
        "success": True,
        "new_version": new_ver,
        "run": new_run,
        "applied_count": len(applied_feedbacks),
        "conflict_count": len(conflicted_feedbacks),
        "conflicts": conflicted_feedbacks,
        "diff": diff_data,
        "reprocess_summary": full_reprocess_summary
    }
