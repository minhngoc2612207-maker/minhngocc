"""
B1. Intake & Validation Module (DataIQ)
Handles business context ingestion, problem statement validation, multi-format file uploads,
sanitization, and automated generation of intentional-error sample datasets.
"""

import os
import re
import io
import json
import uuid
from typing import Dict, Any, List, Tuple, Optional
import pandas as pd
import numpy as np

ALLOWED_EXTENSIONS = {".csv", ".xlsx", ".xls", ".json", ".pdf", ".docx", ".txt"}
MAX_FILE_SIZE_BYTES = 30 * 1024 * 1024  # 30 MB


def sanitize_filename(filename: str) -> str:
    """Sanitizes filename against path traversal and unsafe characters while preserving Vietnamese text."""
    base = os.path.basename(filename).strip()
    cleaned = re.sub(r'[\/\\:*?"<>|]', '_', base)
    cleaned = re.sub(r'\.\.+', '.', cleaned)
    if not cleaned or cleaned.startswith('.'):
        cleaned = f"upload_{uuid.uuid4().hex[:8]}.dat"
    return cleaned


def validate_intake_payload(
    problem_statement: str,
    files: List[Any],
    business_context: Optional[Dict[str, Any]] = None,
    column_descriptions: Optional[Dict[str, str]] = None
) -> Tuple[bool, str, Dict[str, Any]]:
    """
    Validates B1 inputs:
    - Problem statement must be non-empty (at least 10 chars).
    - At least 1 valid file must be provided.
    - Files must have valid extension and size within bounds.
    """
    prob = (problem_statement or "").strip()
    if not prob:
        return False, "Vui lòng nhập mô tả vấn đề doanh nghiệp đang gặp phải.", {}
    if len(prob) < 5:
        return False, "Mô tả vấn đề quá ngắn. Vui lòng cung cấp chi tiết hơn để Agent hiểu đúng ngữ cảnh.", {}

    if not files or len(files) == 0:
        return False, "Vui lòng tải lên ít nhất 1 tệp dữ liệu thô (CSV, XLSX, JSON, PDF, DOCX, TXT).", {}

    valid_files_meta = []
    for f in files:
        fname = getattr(f, "filename", None) or getattr(f, "name", None) or str(f)
        fname = sanitize_filename(fname)
        ext = os.path.splitext(fname)[1].lower()
        if ext not in ALLOWED_EXTENSIONS:
            return False, f"Định dạng tệp '{fname}' không được hỗ trợ. Các định dạng cho phép: {', '.join(sorted(ALLOWED_EXTENSIONS))}", {}
        valid_files_meta.append({"filename": fname, "ext": ext})

    ctx = business_context or {}
    cols = column_descriptions or {}

    normalized = {
        "problem_statement": prob,
        "business_context": {
            "industry": ctx.get("industry", "Thương mại & Bán lẻ"),
            "scale": ctx.get("scale", "Doanh nghiệp vừa và nhỏ (SME)"),
            "business_model": ctx.get("business_model", "B2B / Kênh đại lý"),
            "currency": ctx.get("currency", "VND"),
            "notes": ctx.get("notes", "")
        },
        "column_descriptions": cols,
        "files_count": len(valid_files_meta)
    }
    return True, "", normalized


# ========================================================
# INTENTIONAL-ERROR SAMPLE GENERATOR
# ========================================================

def ensure_sample_files(target_dir: str):
    """
    Generates standard testing datasets intentionally infused with errors:
    1. scenario_success_retail_sales.xlsx (Rich dataset with duplicates, formatting errors, outliers, math errors)
    2. scenario_cross_reconciliation_debt.csv (Cross-matching file with customer debt balance mismatches)
    3. scenario_corrupted_file.xlsx (Corrupt byte stream for Error Branch B4 testing)
    4. scenario_missing_key_columns.csv (Missing critical columns for Gatekeeper testing)
    """
    os.makedirs(target_dir, exist_ok=True)

    # 1. Main Retail Sales File (XLSX multi-sheet)
    f1_path = os.path.join(target_dir, "scenario_success_retail_sales.xlsx")
    if not os.path.exists(f1_path):
        _create_retail_sales_sample(f1_path)

    # 2. Debt Ledger CSV
    f2_path = os.path.join(target_dir, "scenario_cross_reconciliation_debt.csv")
    if not os.path.exists(f2_path):
        _create_debt_sample(f2_path)

    # 3. Corrupted File (B4 testing)
    f3_path = os.path.join(target_dir, "scenario_corrupted_file.xlsx")
    if not os.path.exists(f3_path):
        with open(f3_path, "wb") as f:
            f.write(b"CORRUPTED_PK_HEADER_INVALID_ZIP_NOT_AN_EXCEL_STREAM_000000000")

    # 4. Missing Key Columns (Gatekeeper rejection testing)
    f4_path = os.path.join(target_dir, "scenario_missing_key_columns.csv")
    if not os.path.exists(f4_path):
        with open(f4_path, "w", encoding="utf-8") as f:
            f.write("Ghi_Chu_1,Ghi_Chu_2,Khong_Co_So_Lieu\n")
            f.write("Day la van ban thong thuong,Khong co cot dinh danh,Khong co so tien\n")
            f.write("Dong ghi chu them,Thong tin ben le,Khong co du lieu nghiep vu\n")


def _create_retail_sales_sample(filepath: str):
    """Generates rich sales data containing deliberate real-world errors."""
    data_sales = [
        # Row 1: Normal
        {"Ma_Don_Hang": "DH-2024-001", "Ngay_Chung_Tu": "2024-01-15", "Ma_Dai_Ly": "DL-01", "Ten_Dai_Ly": "Công ty TNHH Ánh Dương", "MST": "0102345678", "SDT": "0903123456", "Khu_Vuc": "Miền Bắc", "San_Pham": "Bếp từ đôi Inverter", "So_Luong": 5, "Don_Gia": "6,500,000 đ", "Thanh_Tien": 32500000, "Trang_Thai": "Hoàn tất"},
        # Row 2: Date format dd/mm/yyyy & Currency string
        {"Ma_Don_Hang": "DH-2024-002", "Ngay_Chung_Tu": "18/01/2024", "Ma_Dai_Ly": "DL-02", "Ten_Dai_Ly": "Đại lý Hoàng Kim Phát", "MST": "0301987654", "SDT": "+84 988 234 567", "Khu_Vuc": "Miền Nam", "San_Pham": "Máy lọc nước RO 9 cấp", "So_Luong": 10, "Don_Gia": "4,200,000 VND", "Thanh_Tien": 42000000, "Trang_Thai": "Hoàn tất"},
        # Row 3: Math Logic Error: 8 * 3,000,000 = 24,000,000 but reported 50,000,000!
        {"Ma_Don_Hang": "DH-2024-003", "Ngay_Chung_Tu": "2024-01-20", "Ma_Dai_Ly": "DL-03", "Ten_Dai_Ly": "Doanh nghiệp tư nhân Sao Mai", "MST": "0103456789", "SDT": "0912-345-678", "Khu_Vuc": "Miền Trung", "San_Pham": "Bình nước nóng 20L", "So_Luong": 8, "Don_Gia": 3000000, "Thanh_Tien": 50000000, "Trang_Thai": "Hoàn tất"},
        # Row 4: Exact duplicate of Row 1!
        {"Ma_Don_Hang": "DH-2024-001", "Ngay_Chung_Tu": "2024-01-15", "Ma_Dai_Ly": "DL-01", "Ten_Dai_Ly": "Công ty TNHH Ánh Dương", "MST": "0102345678", "SDT": "0903123456", "Khu_Vuc": "Miền Bắc", "San_Pham": "Bếp từ đôi Inverter", "So_Luong": 5, "Don_Gia": "6,500,000 đ", "Thanh_Tien": 32500000, "Trang_Thai": "Hoàn tất"},
        # Row 5: Fuzzy Duplicate name: "Cty TNHH Ánh Dương (Chi nhánh)" vs "Công ty TNHH Ánh Dương"
        {"Ma_Don_Hang": "DH-2024-004", "Ngay_Chung_Tu": "2024-01-25", "Ma_Dai_Ly": "DL-01-CN", "Ten_Dai_Ly": "Cty TNHH Ánh Dương (CN)", "MST": "0102345678-001", "SDT": "0903123456", "Khu_Vuc": "Miền Bắc", "San_Pham": "Quạt điều hòa công suất lớn", "So_Luong": 12, "Don_Gia": 2800000, "Thanh_Tien": 33600000, "Trang_Thai": "Hoàn tất"},
        # Row 6: Outlier Revenue & Quantity: 999 units, 9,990,000,000 VND (Anomalous typo)
        {"Ma_Don_Hang": "DH-2024-005", "Ngay_Chung_Tu": "2024-02-02", "Ma_Dai_Ly": "DL-04", "Ten_Dai_Ly": "Công ty CP Thương mại Quốc tế Tiến Phát", "MST": "0105678901", "SDT": "0977889900", "Khu_Vuc": "Miền Nam", "San_Pham": "Bếp từ đôi Inverter", "So_Luong": 999, "Don_Gia": 10000000, "Thanh_Tien": 9990000000, "Trang_Thai": "Treo chờ duyệt"},
        # Row 7: Missing customer ID and negative amount
        {"Ma_Don_Hang": "DH-2024-006", "Ngay_Chung_Tu": "2024-02-05", "Ma_Dai_Ly": None, "Ten_Dai_Ly": "Đại lý Bách Khoa Gia Dụng", "MST": None, "SDT": "0934567890", "Khu_Vuc": "Miền Bắc", "San_Pham": "Máy lọc nước RO 9 cấp", "So_Luong": -2, "Don_Gia": 4200000, "Thanh_Tien": -8400000, "Trang_Thai": "Hàng trả lại"},
        # Row 8: Wrong Date: 31/02/2024 (invalid day in February)
        {"Ma_Don_Hang": "DH-2024-007", "Ngay_Chung_Tu": "31/02/2024", "Ma_Dai_Ly": "DL-05", "Ten_Dai_Ly": "Công ty TNHH Dịch vụ Vạn Lộc", "MST": "0401122334", "SDT": "0945667788", "Khu_Vuc": "Miền Trung", "San_Pham": "Bình nước nóng 20L", "So_Luong": 15, "Don_Gia": "3,100,000 đ", "Thanh_Tien": 46500000, "Trang_Thai": "Hoàn tất"},
        # Row 9: Missing Product and Category
        {"Ma_Don_Hang": "DH-2024-008", "Ngay_Chung_Tu": "2024-02-14", "Ma_Dai_Ly": "DL-02", "Ten_Dai_Ly": "Đại lý Hoàng Kim Phát", "MST": "0301987654", "SDT": "0988234567", "Khu_Vuc": None, "San_Pham": None, "So_Luong": 4, "Don_Gia": 5000000, "Thanh_Tien": 20000000, "Trang_Thai": "Hoàn tất"},
        # Row 10: Internal Branch (Lesson Candidate: Mã DL-NB01 là nội bộ)
        {"Ma_Don_Hang": "DH-2024-009", "Ngay_Chung_Tu": "2024-02-20", "Ma_Dai_Ly": "DL-NB01", "Ten_Dai_Ly": "Kho Điều chuyển Miền Bắc (Nội bộ)", "MST": "0100112233", "SDT": "02438889999", "Khu_Vuc": "Miền Bắc", "San_Pham": "Quạt điều hòa công suất lớn", "So_Luong": 50, "Don_Gia": 2200000, "Thanh_Tien": 110000000, "Trang_Thai": "Điều chuyển"}
    ]

    data_products = [
        {"Ma_San_Pham": "SP-01", "Ten_San_Pham": "Bếp từ đôi Inverter", "Nganh_Hang": "Bếp & Thiết bị nhiệt", "Gia_Niem_Yet": 6500000, "Bao_Hanh_Thang": 24},
        {"Ma_San_Pham": "SP-02", "Ten_San_Pham": "Máy lọc nước RO 9 cấp", "Nganh_Hang": "Xử lý nước", "Gia_Niem_Yet": 4200000, "Bao_Hanh_Thang": 36},
        {"Ma_San_Pham": "SP-03", "Ten_San_Pham": "Bình nước nóng 20L", "Nganh_Hang": "Thiết bị nhiệt", "Gia_Niem_Yet": 3100000, "Bao_Hanh_Thang": 24},
        {"Ma_San_Pham": "SP-04", "Ten_San_Pham": "Quạt điều hòa công suất lớn", "Nganh_Hang": "Làm mát", "Gia_Niem_Yet": 2800000, "Bao_Hanh_Thang": 12},
    ]

    df_sales = pd.DataFrame(data_sales)
    df_products = pd.DataFrame(data_products)

    with pd.ExcelWriter(filepath, engine="openpyxl") as writer:
        df_sales.to_excel(writer, sheet_name="Doanh_Thu_Dai_Ly", index=False)
        df_products.to_excel(writer, sheet_name="Danh_Muc_San_Pham", index=False)


def _create_debt_sample(filepath: str):
    """Generates customer debt ledger for cross-file reconciliation with discrepancies."""
    data_debt = [
        {"Ma_Dai_Ly": "DL-01", "Ten_Dai_Ly": "Công ty TNHH Ánh Dương", "Cong_No_Dau_Ky": 15000000, "Phat_Sinh_Trong_Ky": 32500000, "Da_Thanh_Toan": 20000000, "Cong_No_Cuoi_Ky": 27500000, "Han_Muc_Tin_Dung": 50000000, "So_Ngay_Qua_Han": 0},
        {"Ma_Dai_Ly": "DL-02", "Ten_Dai_Ly": "Đại lý Hoàng Kim Phát", "Cong_No_Dau_Ky": 80000000, "Phat_Sinh_Trong_Ky": 62000000, "Da_Thanh_Toan": 10000000, "Cong_No_Cuoi_Ky": 132000000, "Han_Muc_Tin_Dung": 100000000, "So_Ngay_Qua_Han": 45}, # Exceeds limit & 45 days overdue!
        {"Ma_Dai_Ly": "DL-03", "Ten_Dai_Ly": "Doanh nghiệp tư nhân Sao Mai", "Cong_No_Dau_Ky": 0, "Phat_Sinh_Trong_Ky": 24000000, "Da_Thanh_Toan": 24000000, "Cong_No_Cuoi_Ky": 0, "Han_Muc_Tin_Dung": 30000000, "So_Ngay_Qua_Han": 0},
        {"Ma_Dai_Ly": "DL-99", "Ten_Dai_Ly": "Đại lý chưa có đơn hàng Ma_99", "Cong_No_Dau_Ky": 5000000, "Phat_Sinh_Trong_Ky": 0, "Da_Thanh_Toan": 0, "Cong_No_Cuoi_Ky": 5000000, "Han_Muc_Tin_Dung": 10000000, "So_Ngay_Qua_Han": 90} # Unmatched partner
    ]
    df_debt = pd.DataFrame(data_debt)
    df_debt.to_csv(filepath, index=False, encoding="utf-8-sig")


def get_sample_manifest() -> List[Dict[str, Any]]:
    """Returns metadata for sample datasets available for 1-click loading."""
    return [
        {
            "id": "scenario_retail_sales",
            "name": "Dữ liệu Bán hàng & Đại lý (Có lỗi thực tế)",
            "description": "File Excel đa sheet chứa dữ liệu doanh thu đại lý với các lỗi: trùng lặp chính xác & mờ, sai lệch số tiền vs số lượng x đơn giá, định dạng ngày lỗi 31/02, giá trị ngoại lai 9.9 tỷ, số tiền âm.",
            "recommended_problem": "Doanh thu đại lý quý 1 biến động bất thường, nghi ngờ trùng lặp đơn hàng, tính sai chiết khấu thành tiền và có các số liệu ngoại lai gây méo mó báo cáo kết quả kinh doanh.",
            "recommended_goals": ["clean_data", "detect_anomalies", "find_root_causes", "risk_assessment", "actionable_recommendations"],
            "filename": "scenario_success_retail_sales.xlsx",
            "file_type": "xlsx",
            "test_case": "Nhánh thành công (Happy Path) & Vòng phản hồi"
        },
        {
            "id": "scenario_debt_reconcile",
            "name": "Sổ theo dõi Công nợ & Hạn mức tín dụng",
            "description": "File CSV theo dõi công nợ đối soát chéo với file bán hàng, phát hiện đại lý vượt trần tín dụng và nợ quá hạn 45 ngày.",
            "recommended_problem": "Đối soát công nợ đại lý với doanh số thực tế, tìm đại lý vượt trần tín dụng và rủi ro nợ xấu.",
            "recommended_goals": ["detect_anomalies", "risk_assessment", "actionable_recommendations"],
            "filename": "scenario_cross_reconciliation_debt.csv",
            "file_type": "csv",
            "test_case": "Đối soát chéo đa file"
        },
        {
            "id": "scenario_corrupted",
            "name": "Tệp lỗi cấu trúc hỏng (Corrupted Stream)",
            "description": "Tệp Excel bị hỏng cấu trúc byte stream, kiểm thử khả năng phát hiện lỗi tự động và chẩn đoán của Gatekeeper.",
            "recommended_problem": "Cố gắng nạp dữ liệu từ tệp xuất lỗi của hệ thống ERP cũ.",
            "recommended_goals": ["clean_data"],
            "filename": "scenario_corrupted_file.xlsx",
            "file_type": "xlsx",
            "test_case": "Nhánh lỗi (Error Branch B4)"
        },
        {
            "id": "scenario_missing_columns",
            "name": "Tệp thiếu cột then chốt nghiệp vụ",
            "description": "Tệp CSV chỉ có các trường ghi chú chung, hoàn toàn thiếu định danh thực thể và số liệu tài chính định lượng.",
            "recommended_problem": "Phân tích doanh số nhưng file tải lên không chứa cột số tiền hay mã giao dịch.",
            "recommended_goals": ["detect_anomalies"],
            "filename": "scenario_missing_key_columns.csv",
            "file_type": "csv",
            "test_case": "Nhánh lỗi (Cổng quyết định Gatekeeper từ chối)"
        }
    ]
