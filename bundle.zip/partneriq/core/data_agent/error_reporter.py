"""
B4. Error Reporter & Diagnostics Generator (DataIQ)
Produces structured, human-readable error diagnostics when processing fails or is blocked.
Includes coordinates (File, Sheet, Row, Col), root causes, remediation instructions,
and export capabilities (XLSX / PDF). Never displays raw stack traces to the end user.
"""

import os
import io
import json
from typing import Dict, Any, List, Optional
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors

from agent.llm_client import call_gemini


def build_error_summary(error_records: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Generates structured error diagnostics summary."""
    blockers = sum(1 for e in error_records if e.get("severity") == "BLOCKER")
    warnings = sum(1 for e in error_records if e.get("severity") == "WARNING")

    return {
        "total_errors": len(error_records),
        "blockers_count": blockers,
        "warnings_count": warnings,
        "is_fatal": blockers > 0,
        "errors": error_records
    }


def generate_friendly_explanation(error_records: List[Dict[str, Any]], problem_statement: str) -> str:
    """
    Produces executive-friendly troubleshooting guidance via Gemini or deterministic fallback.
    """
    if not error_records:
        return "Không có lỗi nghiêm trọng nào được ghi nhận."

    prompt = f"""
Người dùng gặp lỗi khi xử lý dữ liệu cho bài toán: "{problem_statement}".
Danh sách chẩn đoán lỗi kỹ thuật:
{json.dumps(error_records[:5], ensure_ascii=False, indent=2)}

Hãy viết một đoạn hướng dẫn khắc phục ngắn gọn (3-4 gạch đầu dòng), lịch sự, dễ hiểu cho người dùng doanh nghiệp
(không dùng từ ngữ kỹ thuật lập trình như exception, traceback, null pointer).
"""
    res = call_gemini(prompt=prompt, temperature=0.2, max_tokens=1000)
    if res.get("success") and res.get("text") and len(res["text"].strip()) > 30:
        return res["text"].strip()

    # Deterministic fallback explanation
    lines = ["**Hướng dẫn khắc phục sự cố dữ liệu:**"]
    for idx, e in enumerate(error_records[:4], 1):
        lines.append(f"{idx}. **{e.get('cause')}**: {e.get('suggested_fix')}")
    lines.append("- *Bạn có thể tải tệp mẫu chuẩn từ hệ thống để tham khảo cấu trúc trước khi thử lại.*")
    return "\n".join(lines)


def export_error_report_to_excel(error_records: List[Dict[str, Any]], job_title: str) -> io.BytesIO:
    """Exports error report to formatted Excel workbook."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Báo Cáo Lỗi"

    # Header style
    header_fill = PatternFill(start_color="DC2626", end_color="DC2626", fill_type="solid")
    header_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    align_center = Alignment(horizontal="center", vertical="center", wrap_text=True)
    thin_border = Border(
        left=Side(style='thin', color='E5E7EB'),
        right=Side(style='thin', color='E5E7EB'),
        top=Side(style='thin', color='E5E7EB'),
        bottom=Side(style='thin', color='E5E7EB')
    )

    # Title row
    ws.merge_cells("A1:I1")
    ws["A1"] = f"BÁO CÁO CHẨN ĐOÁN LỖI DỮ LIỆU - {job_title.upper()}"
    ws["A1"].font = Font(name="Calibri", size=14, bold=True, color="DC2626")
    ws["A1"].alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[1].height = 30

    headers = ["STT", "Mã Lỗi", "Mức Độ", "Tệp Nguồn", "Trang Tính", "Tọa Độ (Dòng:Cột)", "Giá Trị Gây Lỗi", "Nguyên Nhân Hỏng", "Đề Xuất Khắc Phục"]
    ws.append([])  # Row 2 empty
    ws.append(headers)  # Row 3
    ws.row_dimensions[3].height = 24

    for col_idx in range(1, len(headers) + 1):
        cell = ws.cell(row=3, column=col_idx)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = align_center

    for idx, err in enumerate(error_records, 1):
        coord = f"Dòng {err.get('row_index', 0)} : Cột {err.get('col_name', '-')}"
        row_vals = [
            idx,
            err.get("error_code", "ERR_DATA"),
            err.get("severity", "BLOCKER"),
            err.get("file_name", "-"),
            err.get("sheet_name", "-"),
            coord,
            str(err.get("offending_value", "")),
            err.get("cause", ""),
            err.get("suggested_fix", "")
        ]
        ws.append(row_vals)
        cur_row = ws.max_row
        ws.row_dimensions[cur_row].height = 22
        for col_idx in range(1, len(headers) + 1):
            c = ws.cell(row=cur_row, column=col_idx)
            c.border = thin_border
            if col_idx in [1, 3]:
                c.alignment = align_center
            if col_idx == 3:
                c.font = Font(bold=True, color="DC2626" if err.get("severity") == "BLOCKER" else "D97706")

    # Auto column width
    for col in ws.columns:
        max_len = max(len(str(cell.value or '')) for cell in col)
        col_letter = get_column_letter(col[0].column)
        ws.column_dimensions[col_letter].width = min(max(max_len + 3, 12), 45)

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf
