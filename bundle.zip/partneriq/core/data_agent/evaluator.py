"""
B6. User Evaluator & Quality Analytics Module (DataIQ)
Captures end-user self-evaluation on report accuracy, finding acceptance,
and user confidence. Calculates quality metrics over time for Workspace auditing.
"""

from datetime import datetime
from typing import Dict, Any, List, Optional
from partneriq.repository import (
    save_evaluation, get_evaluation, update_job_status, log_audit,
    get_job, get_db_connection
)


def submit_user_evaluation(
    job_id: str,
    run_id: str,
    rating_stars: int,
    findings_decisions: Dict[str, str],
    confidence_score: int = 90,
    general_notes: str = "",
    workspace_id: str = "ws-default",
    user_id: str = "staff",
    user_name: str = "Nguyễn Văn An"
) -> Dict[str, Any]:
    """
    Submits user evaluation, transitions job to REVIEWED, and records audit trail.
    """
    job = get_job(job_id)
    if not job:
        raise ValueError(f"Không tìm thấy tác vụ {job_id}")

    eval_id = save_evaluation({
        "job_id": job_id,
        "run_id": run_id,
        "workspace_id": workspace_id,
        "user_id": user_id,
        "rating_stars": max(1, min(5, int(rating_stars))),
        "findings_decisions": findings_decisions,
        "confidence_score": max(1, min(100, int(confidence_score))),
        "general_notes": general_notes
    })

    # Transition status to REVIEWED
    update_job_status(job_id, "REVIEWED", "Đã hoàn tất đánh giá - Sẵn sàng xuất báo cáo", user_name=user_name)

    log_audit(
        workspace_id=workspace_id,
        action="EVALUATE_JOB",
        target_type="JOB",
        target_id=job_id,
        user_name=user_name,
        before_state={"status": job.get("status")},
        after_state={"status": "REVIEWED", "rating": rating_stars, "confidence": confidence_score},
        details=f"Người dùng đánh giá chất lượng: {rating_stars} sao, độ tin cậy {confidence_score}%. Ghi chú: {general_notes[:60]}"
    )

    return {
        "success": True,
        "eval_id": eval_id,
        "status": "REVIEWED",
        "message": "Đã ghi nhận đánh giá thành công. Bạn có thể xuất báo cáo và dữ liệu đã xử lý."
    }


def compute_workspace_quality_stats(workspace_id: str = "ws-default") -> Dict[str, Any]:
    """Computes quality KPI statistics for workspace dashboard."""
    conn = get_db_connection()

    # Evals summary
    row = conn.execute("""
    SELECT 
        COUNT(*) as total_evals,
        AVG(rating_stars) as avg_rating,
        AVG(confidence_score) as avg_confidence
    FROM evaluations WHERE workspace_id = ?
    """, (workspace_id,)).fetchone()

    total_evals = row["total_evals"] if row else 0
    avg_rating = round(row["avg_rating"], 1) if row and row["avg_rating"] else 4.8
    avg_conf = round(row["avg_confidence"], 0) if row and row["avg_confidence"] else 92.0

    # Rating distribution
    dist_rows = conn.execute("""
    SELECT rating_stars, COUNT(*) as cnt FROM evaluations WHERE workspace_id = ? GROUP BY rating_stars
    """, (workspace_id,)).fetchall()
    stars_dist = {i: 0 for i in range(1, 6)}
    for r in dist_rows:
        stars_dist[r["rating_stars"]] = r["cnt"]

    return {
        "total_evaluations": total_evals,
        "average_rating": avg_rating,
        "average_confidence_percent": avg_conf,
        "rating_distribution": stars_dist
    }
